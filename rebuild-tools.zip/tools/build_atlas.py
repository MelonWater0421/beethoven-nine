#!/usr/bin/env python3
"""Build data.js, 16 concert-pitch MIDI excerpts, and tools/sources.json for Beethoven 9 Atlas."""

from __future__ import annotations

import copy
import json
import os
import pathlib
import struct
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
TOOLS = ROOT / "tools"
CACHE = TOOLS / "score-cache"
RESEARCH = TOOLS / "research"
ASSETS = ROOT / "assets"

sys.path.insert(0, str(TOOLS))
import enrichment_meta as meta  # noqa: E402
import enrichment_m1_m2 as m12  # noqa: E402
import enrichment_m3_m4 as m34  # noqa: E402

CHOIR_IDS = ["strings", "winds", "horns", "brass", "perc", "voices"]

RADAR_GROUPS_ZH = [
    ["strings", "🎻", "弦乐群"],
    ["winds",   "🪈", "木管声部"],
    ["horns",   "📯", "圆号 (4支)"],
    ["brass",   "🎺", "小号 / 长号"],
    ["perc",    "🥁", "定音鼓 / 弦外打击乐"],
    ["voices",  "🎭", "独唱与合唱"],
]

RADAR_GROUPS_EN = [
    ["strings", "🎻", "Strings"],
    ["winds",   "🪈", "Woodwinds"],
    ["horns",   "📯", "Horns (4)"],
    ["brass",   "🎺", "Trumpets / Trombones"],
    ["perc",    "🥁", "Timpani / Turkish Perc."],
    ["voices",  "🎭", "Soloists & Chorus"],
]

NOTE_NAMES = ["C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"]

# app.js scheduleSynthVoice tests /Soprano|Alto|Tenor.../ BEFORE /Trombone/
# Keep human-readable UI titles unchanged while remapping sourcePart aliases cleanly.
SYNTH_SOURCE_PART_ALIAS = {
    "Alto Trombone": "Trombone (Alt.)",
    "Tenor Trombone": "Trombone (Ten.)",
}


def midi_to_label(midi: int, source_part: str, unpitched: bool) -> str:
    """Format concise pitch or percussion badge for Piano Roll pills."""
    if unpitched:
        low = source_part.lower()
        if "triangle" in low:
            return "△"
        if "cymbal" in low:
            return "◎"
        if "drum" in low:
            return "BD"
        return "●"
    octave = (midi // 12) - 1
    return f"{NOTE_NAMES[midi % 12]}{octave}"


def gm_program_for_part(source_part: str) -> int:
    """Select an expressive General MIDI program (0-127) for an orchestral or choral part."""
    p = source_part.lower()
    if "timpani" in p:
        return 47
    if "piccolo" in p:
        return 72
    if "flute" in p:
        return 73
    if "oboe" in p:
        return 68
    if "clarinet" in p:
        return 71
    if "contrabassoon" in p or "bassoon" in p:
        return 70
    if "horn" in p:
        return 60
    if "trumpet" in p:
        return 56
    if "trombone" in p:
        return 57
    if any(k in p for k in ("soprano", "alto", "tenor")) or p == "bass":
        return 52
    if "violin" in p:
        return 40
    if "viola" in p:
        return 41
    if "cello" in p:
        return 42
    if "contrabass" in p:
        return 43
    return 48


def write_vlq(val: int) -> bytes:
    """Encode non-negative integer as MIDI Variable Length Quantity."""
    val = max(0, int(val))
    buf = [val & 0x7F]
    val >>= 7
    while val:
        buf.append((val & 0x7F) | 0x80)
        val >>= 7
    buf.reverse()
    return bytes(buf)


def encode_meta_text(meta_type: int, text: str) -> bytes:
    raw = text.encode("utf-8")
    return bytes([0xFF, meta_type]) + write_vlq(len(raw)) + raw


def encode_track_chunk(events: list[tuple[int, int, bytes]], total_ticks: int) -> bytes:
    """Sort events, convert absolute ticks to deltas, append End-of-Track at exact total_ticks."""
    events_sorted = sorted(events, key=lambda x: (x[0], x[1]))
    body = bytearray()
    last_tick = 0
    for tick, _, payload in events_sorted:
        clamped = min(total_ticks, max(last_tick, int(tick)))
        body.extend(write_vlq(clamped - last_tick))
        body.extend(payload)
        last_tick = clamped
    rem = max(0, total_ticks - last_tick)
    body.extend(write_vlq(rem))
    body.extend(b"\xFF\x2F\x00")
    return b"MTrk" + struct.pack(">L", len(body)) + bytes(body)


def write_smf_type1(
    path: pathlib.Path,
    title: str,
    bpm: float,
    total_beats: float,
    tracks_data: list[dict],
) -> None:
    """Write a clean Standard MIDI File (Type 1) whose duration matches totalBeats * 60 / bpm."""
    tpb = 480
    total_ticks = max(1, int(round(total_beats * tpb)))
    us_per_q = max(1, int(round(60_000_000.0 / bpm)))

    # Track 0: tempo & title
    t0_events: list[tuple[int, int, bytes]] = [
        (0, 0, encode_meta_text(0x03, title)),
        (0, 1, b"\xFF\x51\x03" + us_per_q.to_bytes(3, "big")),
    ]
    chunks = [encode_track_chunk(t0_events, total_ticks)]

    next_melodic_ch = 0
    for trk in tracks_data:
        unpitched_trk = bool(trk.get("_unpitched"))
        if unpitched_trk:
            ch = 9  # GM Percussion channel
        else:
            if next_melodic_ch == 9:
                next_melodic_ch += 1
            ch = next_melodic_ch % 16
            if ch == 9:
                next_melodic_ch += 1
                ch = next_melodic_ch % 16
            next_melodic_ch += 1

        evts: list[tuple[int, int, bytes]] = [
            (0, 0, encode_meta_text(0x03, trk["name_en"])),
        ]
        if not unpitched_trk:
            prog = gm_program_for_part(trk["_origSourcePart"])
            evts.append((0, 1, bytes([0xC0 | ch, prog])))

        vel = 84 if not unpitched_trk else 96
        for n in trk["notes"]:
            t_on = int(round(n["start"] * tpb))
            t_off = int(round((n["start"] + n["dur"]) * tpb))
            if t_on >= total_ticks:
                continue
            t_off = min(total_ticks, max(t_on + 24, t_off))
            pitch = max(0, min(127, int(n["midi"])))
            # Note-off sorts before note-on when at identical tick (priority 2 < 3)
            evts.append((t_on, 3, bytes([0x90 | ch, pitch, vel])))
            evts.append((t_off, 2, bytes([0x80 | ch, pitch, 0])))

        chunks.append(encode_track_chunk(evts, total_ticks))

    header = b"MThd" + struct.pack(">LHHH", 6, 1, len(chunks), tpb)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(header + b"".join(chunks))


def lookup_sec(bar_events: list[dict], bar: int, occ: str | None = None) -> float:
    """Resolve bar (and optional occurrence tag in M2) to recording timestamp in seconds."""
    if occ:
        for ev in bar_events:
            if ev["bar"] == bar and ev.get("occ", "") == occ:
                return float(ev["sec"])
    for ev in bar_events:
        if ev["bar"] == bar:
            return float(ev["sec"])
    raise KeyError(f"Could not find bar={bar} occ={occ!r} in barEvents")


def extract_excerpt_mode(
    ex: dict,
    score_data: dict,
    bar_events: list[dict],
    edition: str,
) -> dict:
    """Extract concert-pitch Piano Roll track notes, merge ties across barlines, and emit MIDI."""
    start_bar = int(ex["startBar"])
    end_bar = int(ex["endBar"])
    slice_bars = [b for b in score_data["bars"] if start_bar <= b["bar"] <= end_bar]
    if not slice_bars:
        raise RuntimeError(f"No bars found for {ex['midi']} ({start_bar}..{end_bar})")

    # Sort slice bars in score order and verify unique written bars
    slice_bars.sort(key=lambda b: b["bar"])
    total_beats = round(sum(float(b["qLen"]) for b in slice_bars), 4)

    bar_lines: list[dict] = []
    bar_offsets: dict[int, float] = {}
    beat_cursor = 0.0
    for b in slice_bars:
        bar_offsets[b["bar"]] = beat_cursor
        bar_lines.append({
            "bar": int(b["bar"]),
            "left": round(100.0 * beat_cursor / total_beats, 2),
        })
        beat_cursor += float(b["qLen"])

    built_tracks: list[dict] = []
    for t_spec in ex["tracks"]:
        src_part = t_spec["sourcePart"]
        raw_notes: list[dict] = []
        unpitched_any = False
        for b in slice_bars:
            off = bar_offsets[b["bar"]]
            b_q = float(b["qLen"])
            for n in b["notes"]:
                if n["part"] != src_part:
                    continue
                if n.get("unpitched"):
                    unpitched_any = True
                s_q = max(0.0, off + float(n["startQ"]))
                e_q = min(total_beats, off + min(b_q, float(n["startQ"]) + float(n["durQ"])))
                if e_q <= s_q:
                    e_q = min(total_beats, s_q + 0.125)
                raw_notes.append({
                    "startQ": s_q,
                    "endQ": e_q,
                    "midi": int(n["midi"]),
                    "unpitched": bool(n.get("unpitched")),
                    "tieStart": bool(n.get("tieStart")),
                    "tieStop": bool(n.get("tieStop")),
                })

        raw_notes.sort(key=lambda x: (x["startQ"], x["midi"]))

        # Merge consecutive tied notes sharing pitch
        merged: list[dict] = []
        open_ties: dict[int, dict] = {}
        seen_starts: set[tuple[float, int]] = set()
        for n in raw_notes:
            pitch = n["midi"]
            if n["tieStop"] and pitch in open_ties:
                prev = open_ties[pitch]
                if abs(n["startQ"] - prev["endQ"]) <= 0.15:
                    prev["endQ"] = max(prev["endQ"], n["endQ"])
                    if not n["tieStart"]:
                        open_ties.pop(pitch, None)
                    continue
                else:
                    open_ties.pop(pitch, None)

            start_r = round(n["startQ"], 3)
            if (start_r, pitch) in seen_starts:
                continue
            seen_starts.add((start_r, pitch))

            entry = {
                "startQ": n["startQ"],
                "endQ": n["endQ"],
                "midi": pitch,
                "unpitched": n["unpitched"],
            }
            merged.append(entry)
            if n["tieStart"]:
                open_ties[pitch] = entry

        formatted_notes = [
            {
                "start": round(m["startQ"], 3),
                "dur": max(0.06, round(m["endQ"] - m["startQ"], 3)),
                "midi": m["midi"],
                "label": midi_to_label(m["midi"], src_part, m["unpitched"]),
            }
            for m in merged
        ]
        if not formatted_notes:
            raise RuntimeError(
                f"Track {t_spec['id']} ({src_part!r}) in {ex['midi']} produced 0 notes!"
            )

        out_trk = {
            "id": t_spec["id"],
            "sourcePart": SYNTH_SOURCE_PART_ALIAS.get(src_part, src_part),
            "_origSourcePart": src_part,
            "_unpitched": unpitched_any,
            "name": t_spec["name"],
            "name_en": t_spec["name_en"],
            "sub": t_spec["sub"],
            "sub_en": t_spec["sub_en"],
            "color": t_spec["color"],
            "notes": formatted_notes,
        }
        if t_spec.get("articulation"):
            out_trk["articulation"] = t_spec["articulation"]
        built_tracks.append(out_trk)

    midi_rel = ex["midi"]
    write_smf_type1(
        ROOT / midi_rel,
        title=f"Beethoven Op.125 Mvt {ex['movement']} - {ex['name_en']}",
        bpm=float(ex["bpm"]),
        total_beats=total_beats,
        tracks_data=built_tracks,
    )

    # Strip internal builder keys before writing to ATLAS_DATA
    for trk in built_tracks:
        trk.pop("_origSourcePart", None)
        trk.pop("_unpitched", None)

    jump_occ = ex.get("jumpOcc") or ex.get("occ")
    real_jump = lookup_sec(bar_events, int(ex["jumpBar"]), jump_occ)

    prov_zh = ex.get(
        "provenance",
        f"实音 MIDI 与钢琴卷帘窗由 OpenScore Op. 125 第 {ex['movement']} 乐章总谱第 {start_bar}–{end_bar} 小节按乐器移调偏置自动转译提取；对应布赖特科普夫原版总谱与卡拉扬 1962 年录音。",
    )
    prov_en = ex.get(
        "provenance_en",
        f"Concert-pitch MIDI and Piano Roll transcribed directly from OpenScore Op. 125 Mvt {ex['movement']} mm. {start_bar}–{end_bar} with per-part <transpose> offsets applied ({edition}).",
    )

    return {
        "midi": midi_rel,
        "name": ex["name"],
        "name_en": ex["name_en"],
        "desc": ex["desc"],
        "desc_en": ex["desc_en"],
        "coord": ex["coord"],
        "coord_en": ex["coord_en"],
        "provenance": prov_zh,
        "provenance_en": prov_en,
        "bpm": float(ex["bpm"]),
        "totalBeats": total_beats,
        "realJumpSec": round(real_jump, 2),
        "barLines": bar_lines,
        "tracks": built_tracks,
    }


def sanitize_choirs(raw_choirs: dict) -> dict:
    """Enforce exact 6 choir keys in canonical order."""
    out = {}
    for cid in CHOIR_IDS:
        c = raw_choirs[cid]
        out[cid] = {
            "active": bool(c["active"]),
            "highlight": bool(c["highlight"]),
            "role": c["role"],
            "role_en": c["role_en"],
        }
    return out


def sanitize_bar_events(raw_events: list[dict]) -> list[dict]:
    """Ensure every barEvent carries all 6 choirs (strings..voices) cleanly."""
    cleaned = []
    for ev in raw_events:
        g_zh = {cid: list(ev["groups"].get(cid, [])) for cid in CHOIR_IDS}
        g_en = {cid: list(ev["groups_en"].get(cid, [])) for cid in CHOIR_IDS}
        item = {
            "bar": int(ev["bar"]),
            "sec": round(float(ev["sec"]), 2),
            "groups": g_zh,
            "groups_en": g_en,
        }
        if ev.get("occ"):
            item["occ"] = ev["occ"]
        cleaned.append(item)
    return cleaned


def build() -> None:
    stage_enrich_all = {**m12.STAGE_ENRICH_M1_M2, **m34.STAGE_ENRICH_M3_M4}
    excerpts_all = m12.EXCERPTS_M1_M2 + m34.EXCERPTS_M3_M4
    edition = meta.WORK_META["edition"]

    movements: list[dict] = []
    sources_report: dict = {"sources": meta.SOURCES, "movements": {}}

    for mvt_id in (1, 2, 3, 4):
        m_meta = copy.deepcopy(meta.MOVEMENTS_META[mvt_id])
        research = json.loads((RESEARCH / f"movement{mvt_id}.json").read_text(encoding="utf-8"))
        score_data = json.loads((CACHE / f"m{mvt_id}.json").read_text(encoding="utf-8"))
        align_data = json.loads((CACHE / f"alignment{mvt_id}.json").read_text(encoding="utf-8"))

        raw_events = align_data["barEvents"]
        bar_events = sanitize_bar_events(raw_events)

        # Build stages
        stages: list[dict] = []
        for idx, rs in enumerate(research["stages"]):
            sid = rs["id"]
            if sid not in stage_enrich_all:
                raise KeyError(f"Missing stage enrichment for {sid!r}")
            enr = copy.deepcopy(stage_enrich_all[sid])
            sec = lookup_sec(raw_events, int(rs["bar"]), rs.get("occ"))

            act_id = int(rs["act"])
            act_zh, act_en = meta.ACTS[mvt_id][act_id]
            pdf_page = int(rs["pdfPage"])
            bar_label = f"第 {rs['bar']} 小节" if rs["bar"] > 0 else "第 0 小节（弱起引子）"
            bar_label_en = f"m. {rs['bar']}" if rs["bar"] > 0 else "m. 0 (upbeat)"

            cues = []
            for c in rs["cues"]:
                c_occ = c.get("occ") or rs.get("occ")
                c_sec = lookup_sec(raw_events, int(c["bar"]), c_occ)
                cues.append({
                    "sec": round(c_sec, 2),
                    "bar": int(c["bar"]),
                    "label": c["label"],
                    "label_en": c["label_en"],
                })
            cues.sort(key=lambda x: x["sec"])

            st_obj = {
                "id": sid,
                "start": round(sec, 2),
                "bar": int(rs["bar"]),
                "endBar": int(rs["endBar"]),
                "act": act_id,
                "actName": act_zh,
                "actName_en": act_en,
                "title": enr["title"],
                "title_en": enr["title_en"],
                "color": rs["color"],
                "blocks": list(rs["blocks"]),
                "focus": enr["focus"],
                "focus_en": enr["focus_en"],
                "foreground": enr["foreground"],
                "foreground_en": enr["foreground_en"],
                "background": enr["background"],
                "background_en": enr["background_en"],
                "desc": enr["desc"],
                "desc_en": enr["desc_en"],
                "score": {
                    "label": f"Breitkopf 第 {pdf_page} 页 · {bar_label}",
                    "label_en": f"Breitkopf p. {pdf_page} · {bar_label_en}",
                    "page": pdf_page,
                    "url": f"{meta.PDF_BASE}#page={pdf_page}",
                },
                "choirs": sanitize_choirs(enr["choirs"]),
                "cues": cues,
            }
            if rs.get("occ"):
                st_obj["occ"] = rs["occ"]
            if enr.get("insights"):
                st_obj["insights"] = copy.deepcopy(enr["insights"])
            stages.append(st_obj)

        # Build motifs
        motifs: list[dict] = []
        for mf in research["motifs"]:
            st_idx = int(mf["stageIndex"])
            target_st = stages[st_idx]
            m_sec = lookup_sec(raw_events, int(mf["bar"]), target_st.get("occ"))
            motifs.append({
                "id": mf["id"],
                "name": mf["name"],
                "name_en": mf["name_en"],
                "earprint": mf["earprint"],
                "earprint_en": mf["earprint_en"],
                "color": mf["color"],
                "stageIndex": st_idx,
                "bar": int(mf["bar"]),
                "audioStart": round(m_sec, 2),
            })

        # Build 4 Piano Roll / MIDI synth modes
        mvt_excerpts = sorted(
            [e for e in excerpts_all if int(e["movement"]) == mvt_id],
            key=lambda x: int(x["index"]),
        )
        synth_modes = [
            extract_excerpt_mode(ex, score_data, raw_events, edition)
            for ex in mvt_excerpts
        ]

        mvt_obj = {
            **m_meta,
            "duration": round(float(align_data["duration"]), 2),
            "barCount": len(bar_events),
            "musicStartSec": round(float(align_data["musicStartSec"]), 2),
            "musicEndSec": round(float(align_data["musicEndSec"]), 2),
            "radarGroups": copy.deepcopy(RADAR_GROUPS_ZH),
            "radarGroups_en": copy.deepcopy(RADAR_GROUPS_EN),
            "barEvents": bar_events,
            "motifs": motifs,
            "stages": stages,
            "synthModes": synth_modes,
        }
        movements.append(mvt_obj)

        sources_report["movements"][str(mvt_id)] = {
            "pdfRange": research["pdfRange"],
            "xmlMeasureCount": score_data.get("xmlMeasureCount"),
            "unrolledBarCount": len(bar_events),
            "durationSec": mvt_obj["duration"],
            "musicStartSec": mvt_obj["musicStartSec"],
            "musicEndSec": mvt_obj["musicEndSec"],
            "anchorsUsed": align_data.get("anchorsUsed", []),
            "m2Resolution": score_data.get("m2Resolution"),
            "excerpts": [
                {
                    "midi": sm["midi"],
                    "coord": sm["coord_en"],
                    "bpm": sm["bpm"],
                    "totalBeats": sm["totalBeats"],
                    "realJumpSec": sm["realJumpSec"],
                    "noteCount": sum(len(t["notes"]) for t in sm["tracks"]),
                }
                for sm in synth_modes
            ],
        }

    # CRITICAL: Hydrate ALL insight links across ALL 4 movements now that every stage start timestamp exists
    stage_lookup: dict[tuple[int, str], float] = {
        (mvt["id"], st["id"]): st["start"]
        for mvt in movements
        for st in mvt["stages"]
    }
    hydrated_links = 0
    for mvt in movements:
        for st in mvt["stages"]:
            for ins in st.get("insights", []):
                if "synthMode" in ins:
                    sm_idx = int(ins["synthMode"])
                    if not (0 <= sm_idx < len(mvt["synthModes"])):
                        raise IndexError(
                            f"Insight {ins['id']} references out-of-range synthMode {sm_idx}"
                        )
                for lk in ins.get("links", []):
                    key = (int(lk["movement"]), lk["stageId"])
                    if key not in stage_lookup:
                        raise KeyError(f"Insight link target not found: {key}")
                    lk["time"] = stage_lookup[key]
                    hydrated_links += 1

    work_meta = copy.deepcopy(meta.WORK_META)
    work_meta["totalStages"] = sum(len(m["stages"]) for m in movements)

    atlas_data = {
        "metadata": work_meta,
        "sources": meta.SOURCES,
        "glossary": meta.GLOSSARY,
        "threads": meta.THREADS,
        "movements": movements,
    }

    (TOOLS / "sources.json").write_text(
        json.dumps(sources_report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    data_js = "window.ATLAS_DATA = " + json.dumps(atlas_data, ensure_ascii=False, separators=(",", ":")) + ";\n"
    (ROOT / "data.js").write_text(data_js, encoding="utf-8")

    total_cues = sum(len(s["cues"]) for m in movements for s in m["stages"])
    total_insights = sum(len(s.get("insights", [])) for m in movements for s in m["stages"])
    total_notes = sum(len(t["notes"]) for m in movements for sm in m["synthModes"] for t in sm["tracks"])
    print(
        f"Built data.js ({len(data_js)/1024:.1f} KB) · "
        f"{work_meta['totalStages']} stages · {total_cues} cues · "
        f"{total_insights} insights ({hydrated_links} cross/intra links hydrated) · "
        f"16 MIDIs ({total_notes} Piano Roll notes)."
    )


if __name__ == "__main__":
    build()
