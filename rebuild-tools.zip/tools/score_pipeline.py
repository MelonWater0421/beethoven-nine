#!/usr/bin/env python3
"""Concert-pitch MusicXML score parser, M2 repeat resolver, and 20Hz/50Hz audio-score aligner
for Beethoven Symphony No. 9 in D minor, Op. 125.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import zipfile
from pathlib import Path
from typing import Any
import xml.etree.ElementTree as ET

import numpy as np
from fastdtw import fastdtw

ROOT = Path(__file__).resolve().parent.parent
TOOLS_DIR = ROOT / "tools"
SCORES_DIR = TOOLS_DIR / "scores"
CACHE_DIR = TOOLS_DIR / "score-cache"
ANCHORS_PATH = TOOLS_DIR / "anchors.json"

CHOIR_IDS = ["strings", "winds", "horns", "brass", "perc", "voices"]
STEP_SEMI = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}

UNPITCHED_MIDI = {
    "Triangle": 81,
    "Cymbals": 49,
    "Bass Drum": 36,
}

# Bilingual localized instrument labels for the 6-choir Score Radar
PART_LABELS: dict[str, tuple[str, str]] = {
    "Piccolo": ("短笛", "Piccolo"),
    "Flute 1": ("长笛 I", "Flute I"),
    "Flute 2": ("长笛 II", "Flute II"),
    "Oboe 1": ("双簧管 I", "Oboe I"),
    "Oboe 2": ("双簧管 II", "Oboe II"),
    "Bb Clarinet 1": ("单簧管 I", "Clarinet I"),
    "Bb Clarinet 2": ("单簧管 II", "Clarinet II"),
    "C Clarinet 1": ("单簧管 I", "Clarinet I"),
    "C Clarinet 2": ("单簧管 II", "Clarinet II"),
    "Bassoon 1": ("大管 I", "Bassoon I"),
    "Bassoon 2": ("大管 II", "Bassoon II"),
    "Contrabassoon": ("低音大管", "Contrabassoon"),
    "D Horn 1": ("圆号 I", "Horn I"),
    "D Horn 2": ("圆号 II", "Horn II"),
    "Bb (alto) Horn 1": ("圆号 I", "Horn I"),
    "Bb (alto) Horn 2": ("圆号 II", "Horn II"),
    "Bb (basso) Horn 3": ("圆号 III", "Horn III"),
    "Bb (basso) Horn 4": ("圆号 IV", "Horn IV"),
    "Eb Horn 3": ("圆号 III", "Horn III"),
    "Eb Horn 4": ("圆号 IV", "Horn IV"),
    "D Trumpet 1": ("小号 I", "Trumpet I"),
    "D Trumpet 2": ("小号 II", "Trumpet II"),
    "Bb Trumpet 1": ("小号 I", "Trumpet I"),
    "Bb Trumpet 2": ("小号 II", "Trumpet II"),
    "Alto Trombone": ("中音长号", "Alto Trombone"),
    "Tenor Trombone": ("次中音长号", "Tenor Trombone"),
    "Bass Trombone": ("低音长号", "Bass Trombone"),
    "D, A Timpani": ("定音鼓", "Timpani"),
    "F, F Timpani": ("定音鼓", "Timpani"),
    "F, Bb Timpani": ("定音鼓", "Timpani"),
    "Triangle": ("三角铁", "Triangle"),
    "Cymbals": ("钹", "Cymbals"),
    "Bass Drum": ("大鼓", "Bass Drum"),
    "Soprano solo": ("女高音独唱", "Soprano Solo"),
    "Alto solo": ("女低音独唱", "Alto Solo"),
    "Tenor solo": ("男高音独唱", "Tenor Solo"),
    "Bass solo": ("男低音独唱", "Bass Solo"),
    "Soprano": ("女高音合唱", "Soprano Chorus"),
    "Alto": ("女低音合唱", "Alto Chorus"),
    "Tenor": ("男高音合唱", "Tenor Chorus"),
    "Bass": ("男低音合唱", "Bass Chorus"),
    "Violin 1": ("小提琴 I", "Violin I"),
    "Violin 2": ("小提琴 II", "Violin II"),
    "Viola": ("中提琴", "Viola"),
    "Violoncello": ("大提琴", "Cello"),
    "Contrabass": ("低音提琴", "Contrabass"),
}


def choir_for_part(name: str) -> str:
    """Map an OpenScore instrument name cleanly to one of the 6 choirs."""
    low = name.strip().lower()
    if any(k in low for k in ("flute", "piccolo", "oboe", "clarinet", "bassoon", "contrabassoon")):
        return "winds"
    if "horn" in low:
        return "horns"
    if any(k in low for k in ("trumpet", "trombone", "tuba")):
        return "brass"
    if any(k in low for k in ("timpani", "triangle", "cymbal", "bass drum")):
        return "perc"
    if any(k in low for k in ("violin", "viola", "violoncello", "cello", "contrabass")):
        return "strings"
    if any(k in low for k in ("soprano", "alto", "tenor", "bass")):
        return "voices"
    raise ValueError(f"Unmapped part name for choir classification: {name!r}")


def _part_weight(choir: str) -> float:
    return {
        "strings": 1.0,
        "winds": 1.05,
        "horns": 1.15,
        "brass": 1.30,
        "perc": 1.20,
        "voices": 1.20,
    }[choir]


def _normalize_part_name(mvt: int, pid: str, raw_name: str) -> str:
    # In M3 XML P11 is labeled "Eb Horn 1" when it is Horn 3 (paired with P12 "Eb Horn 4").
    if mvt == 3 and pid == "P11" and raw_name.strip() == "Eb Horn 1":
        return "Eb Horn 3"
    return raw_name.strip()


def _label_pair(name: str) -> tuple[str, str]:
    if name in PART_LABELS:
        return PART_LABELS[name]
    return (name, name)


def parse_mxl(mvt: int, mxl_path: Path) -> dict[str, Any]:
    """Parse MusicXML archive to concert-pitch bar events and note spans."""
    with zipfile.ZipFile(mxl_path) as zf:
        xml_names = [n for n in zf.namelist() if n.endswith(".xml") and not n.startswith("META-INF")]
        if not xml_names:
            raise FileNotFoundError(f"No XML found inside {mxl_path}")
        root = ET.fromstring(zf.read(xml_names[0]))

    part_defs: list[dict[str, Any]] = []
    for sp in root.findall(".//part-list/score-part"):
        pid = sp.get("id")
        raw_name = (sp.findtext("part-name") or pid or "").strip()
        name = _normalize_part_name(mvt, pid, raw_name)
        choir = choir_for_part(name)
        zh, en = _label_pair(name)
        part_defs.append({"id": pid, "name": name, "choir": choir, "zh": zh, "en": en})

    # Per-part parse keyed by XML measure number (1..N)
    parts_xml: dict[str, dict[int, list[dict[str, Any]]]] = {}
    meas_meta: dict[int, dict[str, Any]] = {}
    num_xml_measures = 0

    for pdef in part_defs:
        pid = pdef["id"]
        part_el = root.find(f"part[@id='{pid}']")
        if part_el is None:
            raise ValueError(f"Missing part element {pid} in M{mvt}")
        divisions = 1
        semitone_shift = 0
        time_sig = "4/4"
        part_bars: dict[int, list[dict[str, Any]]] = {}

        for meas_el in part_el.findall("measure"):
            xml_num = int(meas_el.get("number"))
            if pid == part_defs[0]["id"]:
                num_xml_measures = max(num_xml_measures, xml_num)

            attr_el = meas_el.find("attributes")
            if attr_el is not None:
                div_txt = attr_el.findtext("divisions")
                if div_txt:
                    divisions = int(div_txt)
                tr_el = attr_el.find("transpose")
                if tr_el is not None:
                    chrom = int(tr_el.findtext("chromatic") or 0)
                    oct_chg = int(tr_el.findtext("octave-change") or 0)
                    semitone_shift = chrom + 12 * oct_chg
                t_el = attr_el.find("time")
                if t_el is not None:
                    b = t_el.findtext("beats")
                    bt = t_el.findtext("beat-type")
                    if b and bt:
                        time_sig = f"{b}/{bt}"

            cur_div = 0
            last_start_div = 0
            max_div = 0
            notes_in_bar: list[dict[str, Any]] = []

            for ch in meas_el:
                tag = ch.tag
                if tag == "backup":
                    dur = int(ch.findtext("duration") or 0)
                    cur_div = max(0, cur_div - dur)
                elif tag == "forward":
                    dur = int(ch.findtext("duration") or 0)
                    cur_div += dur
                    max_div = max(max_div, cur_div)
                elif tag == "note":
                    if ch.find("grace") is not None:
                        continue
                    dur_div = int(ch.findtext("duration") or 0)
                    is_chord = ch.find("chord") is not None
                    start_div = last_start_div if is_chord else cur_div
                    if not is_chord:
                        last_start_div = cur_div
                        cur_div += dur_div
                    max_div = max(max_div, cur_div)

                    if ch.find("rest") is not None:
                        continue
                    if ch.get("print-object") == "no":
                        continue
                    nh = ch.find("notehead")
                    if nh is not None and (nh.text or "").strip().lower() == "none":
                        continue

                    tie_types = {t.get("type") for t in ch.findall("tie")}
                    pitch_el = ch.find("pitch")
                    midi_pitch: int | None = None
                    is_unpitched = False
                    if pitch_el is not None:
                        step = (pitch_el.findtext("step") or "C").strip()
                        alter = int(float(pitch_el.findtext("alter") or 0))
                        octave = int(pitch_el.findtext("octave") or 4)
                        midi_pitch = (octave + 1) * 12 + STEP_SEMI[step] + alter + semitone_shift
                    elif ch.find("unpitched") is not None:
                        is_unpitched = True
                        midi_pitch = UNPITCHED_MIDI.get(pdef["name"], 60)
                    else:
                        continue

                    notes_in_bar.append({
                        "partId": pid,
                        "part": pdef["name"],
                        "choir": pdef["choir"],
                        "startQ": start_div / divisions,
                        "durQ": max(0.05, dur_div / divisions),
                        "midi": midi_pitch,
                        "unpitched": is_unpitched,
                        "tieStart": "start" in tie_types,
                        "tieStop": "stop" in tie_types,
                    })

            part_bars[xml_num] = notes_in_bar
            if pid == part_defs[0]["id"]:
                # Ensure full measure duration across voices/staves
                fallback_q = 4.0
                if "/" in time_sig:
                    num_s, den_s = time_sig.split("/")
                    fallback_q = float(num_s) * 4.0 / float(den_s)
                qlen = max_div / divisions if max_div > 0 else fallback_q
                meas_meta[xml_num] = {"xml": xml_num, "timeSig": time_sig, "qLen": round(qlen, 4)}

        parts_xml[pid] = part_bars

    # Assemble canonical score bars per movement matching Breitkopf & Hartel numbering
    raw_bars: list[dict[str, Any]] = []

    def build_bar(bar_num: int, xml_sources: list[int], occ_tag: str = "") -> dict[str, Any]:
        offset_q = 0.0
        total_q = 0.0
        merged_notes: list[dict[str, Any]] = []
        active_pids: set[str] = set()
        t_sig = meas_meta[xml_sources[0]]["timeSig"]
        for xnum in xml_sources:
            meta = meas_meta[xnum]
            for pdef in part_defs:
                pid = pdef["id"]
                pnotes = parts_xml[pid].get(xnum, [])
                if pnotes:
                    active_pids.add(pid)
                    for nt in pnotes:
                        copy_nt = dict(nt)
                        copy_nt["startQ"] = round(nt["startQ"] + offset_q, 5)
                        merged_notes.append(copy_nt)
            offset_q += meta["qLen"]
            total_q += meta["qLen"]

        groups = {c: [] for c in CHOIR_IDS}
        groups_en = {c: [] for c in CHOIR_IDS}
        for pdef in part_defs:
            if pdef["id"] in active_pids:
                c = pdef["choir"]
                groups[c].append(pdef["zh"])
                groups_en[c].append(pdef["en"])

        return {
            "bar": bar_num,
            "xmlBars": xml_sources,
            "occ": occ_tag,
            "timeSig": t_sig,
            "qLen": round(total_q, 4),
            "groups": groups,
            "groups_en": groups_en,
            "notes": merged_notes,
        }

    if mvt in (1, 3):
        for x in range(1, num_xml_measures + 1):
            raw_bars.append(build_bar(x, [x]))
    elif mvt == 2:
        for x in range(1, num_xml_measures + 1):
            raw_bars.append(build_bar(x, [x]))
    elif mvt == 4:
        # Bar 0 = xml_1 (1.0q Bb upbeat); xml_596+597 -> bar 595; xml_657+658 -> bar 655
        raw_bars.append(build_bar(0, [1]))
        for x in range(2, 596):
            raw_bars.append(build_bar(x - 1, [x]))
        raw_bars.append(build_bar(595, [596, 597]))
        for x in range(598, 657):
            raw_bars.append(build_bar(x - 2, [x]))
        raw_bars.append(build_bar(655, [657, 658]))
        for x in range(659, num_xml_measures + 1):
            raw_bars.append(build_bar(x - 3, [x]))

    return {
        "movement": mvt,
        "parts": part_defs,
        "xmlMeasureCount": num_xml_measures,
        "bars": raw_bars,
    }


def unroll_m2_bars(
    written_bars: list[dict[str, Any]],
    s1: bool = True,
    s2: bool = False,
    t1: bool = True,
    t2: bool = True,
    dc1: bool = False,
    dc2: bool = False,
) -> list[dict[str, Any]]:
    """Unroll M2 Scherzo repeats according to candidate boolean flags."""
    by_num = {b["bar"]: b for b in written_bars}
    seq: list[dict[str, Any]] = []

    def push_range(a: int, b: int, occ: str) -> None:
        for k in range(a, b + 1):
            bar_copy = dict(by_num[k])
            bar_copy["occ"] = occ
            seq.append(bar_copy)

    # First Scherzo statement
    push_range(1, 8, "p1")
    push_range(9, 150, "p1")
    if s1:
        push_range(9, 150, "p1r")
    push_range(151, 158, "p1")
    if s2:
        push_range(159, 399, "p1")
        push_range(159, 387, "p1r")
        push_range(400, 423, "p1")
    else:
        push_range(159, 387, "p1")
        push_range(400, 423, "p1")

    # Trio transition & Trio
    push_range(424, 427, "tr")
    if t1:
        push_range(428, 435, "tr1")
        push_range(428, 434, "tr1r")
        push_range(436, 436, "tr1r")
    else:
        push_range(428, 433, "tr1")
        push_range(436, 436, "tr1")

    push_range(437, 506 if t2 else 505, "tr2")
    if t2:
        push_range(437, 505, "tr2r")
    push_range(507, 546, "tr_out")

    # Da Capo al Coda
    push_range(1, 8, "dc")
    push_range(9, 150, "dc")
    if dc1:
        push_range(9, 150, "dcr")
    push_range(151, 158, "dc")
    if dc2:
        push_range(159, 399, "dc")
        push_range(159, 387, "dcr")
        push_range(400, 407, "dc")
    else:
        push_range(159, 387, "dc")
        push_range(400, 407, "dc")

    # Coda
    push_range(547, 575, "coda")
    return seq


def _bar_duration_prior(mvt: int, bar: dict[str, Any]) -> float:
    """Relative duration prior (approximate seconds) so heterogeneous meters align proportionally."""
    bnum = bar["bar"]
    qlen = bar["qLen"]
    ts = bar["timeSig"]
    if mvt == 1:
        return 1.68 * (qlen / 2.0)
    if mvt == 2:
        if 424 <= bnum <= 546 or bnum >= 554:
            # Trio Presto (2/2)
            return 0.56 * (qlen / 4.0)
        return 0.54 * (qlen / 3.0)
    if mvt == 3:
        if (25 <= bnum <= 42) or (65 <= bnum <= 82):
            return 3.2 * (qlen / 3.0)
        return 7.1 * (qlen / 4.0)
    if mvt == 4:
        if bnum == 0:
            return 0.65
        if bnum <= 91:
            return 1.95 * (qlen / 3.0)
        if bnum <= 207:
            return 1.68 * (qlen / 4.0)
        if bnum <= 236:
            return 1.95 * (qlen / 3.0)
        if bnum <= 330:
            return 1.68 * (qlen / 4.0)
        if bnum <= 594:
            return 0.95 * (qlen / 3.0)
        if bnum <= 654:
            return 3.35 * (qlen / 6.0)
        if bnum <= 762:
            return 1.32 * (qlen / 6.0)
        if bnum <= 850:
            return 1.50 * (qlen / 4.0)
        return 0.96 * (qlen / 4.0)
    return 1.0


def synthesize_score_features(
    mvt: int, bars: list[dict[str, Any]], total_frames: int
) -> tuple[np.ndarray, np.ndarray]:
    """Synthesize unit-normalized CQT+energy+onset matrix of shape (total_frames, 14)
    and return (features, bar_start_frame_indices).
    """
    priors = np.array([_bar_duration_prior(mvt, b) for b in bars], dtype=np.float64)
    cum = np.concatenate([[0.0], np.cumsum(priors)])
    total_prior = float(cum[-1])
    bar_starts = np.clip(np.round(cum[:-1] / total_prior * total_frames).astype(int), 0, max(0, total_frames - 1))

    chroma = np.zeros((total_frames, 12), dtype=np.float32)
    energy = np.zeros(total_frames, dtype=np.float32)
    onset = np.zeros(total_frames, dtype=np.float32)

    for idx, bar in enumerate(bars):
        f0 = int(bar_starts[idx])
        f1 = int(bar_starts[idx + 1]) if idx + 1 < len(bars) else total_frames
        if f1 <= f0:
            f1 = min(total_frames, f0 + 1)
        qlen = max(0.25, float(bar["qLen"]))
        span = f1 - f0

        for nt in bar["notes"]:
            w = _part_weight(nt["choir"])
            rel0 = max(0.0, min(1.0, nt["startQ"] / qlen))
            rel1 = max(rel0 + 1e-4, min(1.0, (nt["startQ"] + nt["durQ"]) / qlen))
            nf0 = min(f1 - 1, f0 + int(math.floor(rel0 * span)))
            nf1 = max(nf0 + 1, min(f1, f0 + int(math.ceil(rel1 * span))))
            energy[nf0:nf1] += w
            if not nt["tieStop"]:
                onset[nf0] += w
            if not nt["unpitched"] and nt["midi"] is not None:
                pc = int(nt["midi"]) % 12
                chroma[nf0:nf1, pc] += w
                # Subtle fifth overtone hint helps brass/string register match
                chroma[nf0:nf1, (pc + 7) % 12] += 0.15 * w

    # L2 normalize CQT chroma frames; normalize RMS & onset envelopes by 95th percentile
    norms = np.linalg.norm(chroma, axis=1, keepdims=True)
    chroma_n = np.where(norms > 1e-6, chroma / np.maximum(norms, 1e-6), 0.0)

    e95 = float(np.percentile(energy, 95)) or 1.0
    o95 = float(np.percentile(onset, 95)) or 1.0
    en_n = np.clip(energy / e95, 0.0, 1.5)[:, None]
    on_n = np.clip(onset / o95, 0.0, 1.5)[:, None]

    feats = np.hstack([chroma_n, en_n * 0.45, on_n * 0.25]).astype(np.float32)
    return feats, bar_starts


def load_audio_features(mvt: int) -> dict[str, Any]:
    npz_path = CACHE_DIR / f"audio{mvt}_20hz.npz"
    d = np.load(npz_path)
    cqt_b = d["cqt_b"].astype(np.float32)  # (12, T)
    rms_b = d["rms_b"].astype(np.float32)  # (T,)
    cqt_T = cqt_b.T  # (T, 12)
    norms = np.linalg.norm(cqt_T, axis=1, keepdims=True)
    cqt_n = np.where(norms > 1e-6, cqt_T / np.maximum(norms, 1e-6), 0.0)

    r95 = float(np.percentile(rms_b, 95)) or 1.0
    en_n = np.clip(rms_b / r95, 0.0, 1.5)
    onset = np.zeros_like(rms_b)
    onset[1:] = np.maximum(0.0, rms_b[1:] - rms_b[:-1])
    o95 = float(np.percentile(onset, 95)) or 1.0
    on_n = np.clip(onset / o95, 0.0, 1.5)

    feats = np.hstack([cqt_n, en_n[:, None] * 0.45, on_n[:, None] * 0.25]).astype(np.float32)
    return {
        "feats": feats,
        "rms50": d["rms50"].astype(np.float32),
        "duration": float(d["duration"]),
        "musicStartSec": float(d["musicStartSec"]),
        "musicEndSec": float(d["musicEndSec"]),
        "hop20": float(d["hop20_sec"]),
        "hop50": float(d["hop50_sec"]),
        "n20": feats.shape[0],
    }


def resolve_m2_repeats(written_m2: list[dict[str, Any]], audio2: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    """Compare M2 Scherzo/Trio/Da-Capo repeat candidates against 1962 Karajan audio2_20hz.npz."""
    candidates = [
        ("S1=F,S2=F,T1=F,T2=F,DC=no", dict(s1=False, s2=False, t1=False, t2=False, dc1=False, dc2=False)),
        ("S1=T,S2=F,T1=F,T2=F,DC=no", dict(s1=True,  s2=False, t1=False, t2=False, dc1=False, dc2=False)),
        ("S1=T,S2=F,T1=T,T2=F,DC=no", dict(s1=True,  s2=False, t1=True,  t2=False, dc1=False, dc2=False)),
        ("S1=T,S2=F,T1=T,T2=T,DC=no", dict(s1=True,  s2=False, t1=True,  t2=True,  dc1=False, dc2=False)),
        ("S1=T,S2=T,T1=T,T2=T,DC=no", dict(s1=True,  s2=True,  t1=True,  t2=True,  dc1=False, dc2=False)),
        ("S1=T,S2=T,T1=F,T2=F,DC=no", dict(s1=True,  s2=True,  t1=False, t2=False, dc1=False, dc2=False)),
        ("S1=T,S2=F,T1=T,T2=T,DC1=T", dict(s1=True,  s2=False, t1=True,  t2=True,  dc1=True,  dc2=False)),
        ("S1=T,S2=T,T1=T,T2=T,DC=full", dict(s1=True, s2=True,  t1=True,  t2=True,  dc1=True,  dc2=True)),
        ("S1=F,S2=F,T1=T,T2=T,DC=no", dict(s1=False, s2=False, t1=True,  t2=True,  dc1=False, dc2=False)),
    ]

    # Downsample 20 Hz -> 4 Hz (~0.25s) so 9 full-movement DTW runs take ~1 second
    step = 5
    aud_ds = audio2["feats"][::step]
    n_ds = aud_ds.shape[0]

    print("\n=== Movement II Repeat Resolution (CQT + Energy + Onset DTW Ablation) ===")
    print(f"{'Candidate':<30} {'Bars':>6} {'DTW_Cost':>10} {'Mean_Cos':>10} {'RMS_r':>8}")
    results: list[tuple[float, str, list[dict[str, Any]]]] = []

    for label, kwargs in candidates:
        seq = unroll_m2_bars(written_m2, **kwargs)
        sc_feats, _ = synthesize_score_features(2, seq, n_ds)
        dist, path = fastdtw(sc_feats, aud_ds, radius=24, dist=2)
        p_arr = np.array(path)
        si, ai = p_arr[:, 0], p_arr[:, 1]
        norm_cost = float(dist / len(path))
        cos_sim = float(np.mean(np.sum(sc_feats[si, :12] * aud_ds[ai, :12], axis=1)))
        rms_r = float(np.corrcoef(sc_feats[si, 12], aud_ds[ai, 12])[0, 1])
        print(f"{label:<30} {len(seq):>6d} {norm_cost:>10.4f} {cos_sim:>10.4f} {rms_r:>8.4f}")
        results.append((norm_cost, label, seq))

    results.sort(key=lambda x: x[0])
    winner_cost, winner_label, winner_seq = results[0]
    print(f"--> WINNER: {winner_label} ({len(winner_seq)} unrolled bars, cost={winner_cost:.4f})\n")
    return winner_label, winner_seq


def align_movement_dtw(
    mvt: int,
    bars: list[dict[str, Any]],
    audio: dict[str, Any],
    anchors: list[dict[str, Any]],
    snap_after_first: bool = True,
) -> tuple[float, list[dict[str, Any]]]:
    """Run piecewise 20Hz DTW between score segments bounded by anchors and apply 50Hz RMS post-silence snapping."""
    n20 = audio["n20"]
    s0 = audio["musicStartSec"]
    s1 = audio["musicEndSec"]
    hop20 = audio["hop20"]
    rms50 = audio["rms50"]
    db50 = 20.0 * np.log10(np.maximum(rms50, 1e-12))

    # Build lookup from (bar, occ) or bar index to index in unrolled bars
    def resolve_bar_idx(anchor: dict[str, Any]) -> int:
        b = int(anchor["bar"])
        occ = anchor.get("occ")
        for idx, bar in enumerate(bars):
            if bar["bar"] == b and (occ is None or bar["occ"] == occ):
                return idx
        raise KeyError(f"M{mvt} anchor bar={b} occ={occ} not found in score")

    knots: list[tuple[int, float]] = [(0, s0)]
    for anc in anchors:
        b_idx = resolve_bar_idx(anc)
        knots.append((b_idx, float(anc["sec"])))
    knots.append((len(bars), s1))
    # Sort and deduplicate cleanly by bar index
    clean_knots: list[tuple[int, float]] = []
    for b_idx, sec in sorted(knots, key=lambda x: (x[0], x[1])):
        if clean_knots and clean_knots[-1][0] == b_idx:
            if b_idx == 0 and sec > s0:
                clean_knots[-1] = (b_idx, sec)
            elif b_idx == len(bars):
                clean_knots[-1] = (b_idx, sec)
            else:
                clean_knots[-1] = (b_idx, sec)
        else:
            clean_knots.append((b_idx, sec))

    bar_secs = np.zeros(len(bars), dtype=np.float64)

    for seg_i in range(len(clean_knots) - 1):
        b0, t0 = clean_knots[seg_i]
        b1, t1 = clean_knots[seg_i + 1]
        if b1 <= b0:
            continue
        f0 = max(0, min(n20 - 1, int(round((t0 - s0) / hop20))))
        f1 = max(f0 + 2, min(n20, int(round((t1 - s0) / hop20))))
        seg_bars = bars[b0:b1]
        aud_seg = audio["feats"][f0:f1]

        # Ensure score segment has enough frames for crisp fastdtw (~20 Hz)
        sc_len = max(len(seg_bars) * 2, aud_seg.shape[0])
        sc_feats, bar_rel_starts = synthesize_score_features(mvt, seg_bars, sc_len)
        _, path = fastdtw(sc_feats, aud_seg, radius=32, dist=2)

        # Invert warping path strictly monotonically: score frame -> median matched audio frame
        buckets: list[list[int]] = [[] for _ in range(sc_len)]
        for si, ai in path:
            buckets[si].append(ai)
        map_a = np.zeros(sc_len, dtype=np.float64)
        last_val = 0.0
        for sf in range(sc_len):
            if buckets[sf]:
                val = float(np.median(buckets[sf]))
                last_val = max(last_val, val)
            map_a[sf] = last_val

        # Map each bar in segment using anchors at endpoints
        span_a = max(1e-6, map_a[-1] - map_a[0]) if len(map_a) > 1 else 1.0
        for rel_i, sf in enumerate(bar_rel_starts):
            if rel_i == 0:
                bar_secs[b0 + rel_i] = t0
            else:
                frac = (map_a[sf] - map_a[0]) / span_a
                t_est = t0 + frac * (t1 - t0)
                bar_secs[b0 + rel_i] = round(t_est, 2)

    # Ensure musicStartSec follows explicit opening anchor if present (e.g. M2/M3/M4 pre-attack tape hiss)
    s0_effective = float(bar_secs[0]) if clean_knots[0][0] == 0 else s0

    # Guarantee strict monotonicity (minimum 0.04s separation)
    for k in range(1, len(bar_secs)):
        if bar_secs[k] <= bar_secs[k - 1]:
            bar_secs[k] = round(bar_secs[k - 1] + 0.04, 2)

    # Post-silence snapping against 50Hz RMS for non-first bars (>= -37 dB unless fermata pause)
    anchor_bar_indices = {b_idx for b_idx, _ in clean_knots}
    if snap_after_first:
        for k in range(1, len(bars)):
            if k in anchor_bar_indices:
                continue
            t = bar_secs[k]
            idx50 = min(len(db50) - 1, max(0, int(round(t / 0.02))))
            if db50[idx50] < -37.0:
                # Search +0.4s forward for attack above -37 dB, guarding monotonicity with k+1
                upper_t = bar_secs[k + 1] - 0.05 if k + 1 < len(bars) else audio["musicEndSec"] - 0.1
                for step_i in range(1, 21):
                    cand_t = t + step_i * 0.02
                    if cand_t >= upper_t:
                        break
                    cand_idx = min(len(db50) - 1, int(round(cand_t / 0.02)))
                    if db50[cand_idx] >= -37.0:
                        bar_secs[k] = round(cand_t, 2)
                        break

    aligned: list[dict[str, Any]] = []
    for k, bar in enumerate(bars):
        idx50 = min(len(db50) - 1, max(0, int(round(bar_secs[k] / 0.02))))
        aligned.append({
            "bar": bar["bar"],
            "occ": bar["occ"],
            "sec": round(float(bar_secs[k]), 2),
            "db50": round(float(db50[idx50]), 2),
            "timeSig": bar["timeSig"],
            "qLen": bar["qLen"],
            "groups": bar["groups"],
            "groups_en": bar["groups_en"],
        })
    return s0_effective, aligned


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--unanchored", action="store_true", help="Run raw DTW without tools/anchors.json")
    parser.add_argument("--skip-m2-ablation", action="store_true", help="Skip M2 candidate comparison table")
    args = parser.parse_args()

    anchors_map: dict[str, list[dict[str, Any]]] = {"1": [], "2": [], "3": [], "4": []}
    if not args.unanchored and ANCHORS_PATH.exists():
        anchors_map = json.loads(ANCHORS_PATH.read_text(encoding="utf-8"))

    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    for mvt in (1, 2, 3, 4):
        mxl_path = SCORES_DIR / f"movement-{mvt}.mxl"
        parsed = parse_mxl(mvt, mxl_path)
        audio = load_audio_features(mvt)

        if mvt == 2:
            if args.skip_m2_ablation:
                winner_label = "S1=T,S2=F,T1=T,T2=T,DC=no"
                bars_for_align = unroll_m2_bars(parsed["bars"], s1=True, s2=False, t1=True, t2=True, dc1=False, dc2=False)
            else:
                winner_label, bars_for_align = resolve_m2_repeats(parsed["bars"], audio)
            parsed["m2Resolution"] = winner_label
            parsed["unrolledBars"] = [
                {k: v for k, v in b.items() if k != "notes"} for b in bars_for_align
            ]
        else:
            bars_for_align = parsed["bars"]

        (CACHE_DIR / f"m{mvt}.json").write_text(json.dumps(parsed, ensure_ascii=False), encoding="utf-8")

        m_anchors = anchors_map.get(str(mvt), [])
        s0_eff, aligned = align_movement_dtw(mvt, bars_for_align, audio, m_anchors)

        out_align = {
            "movement": mvt,
            "duration": audio["duration"],
            "musicStartSec": round(s0_eff, 2),
            "musicEndSec": audio["musicEndSec"],
            "barCount": len(parsed["bars"]) - (1 if mvt == 4 else 0),
            "unrolledCount": len(bars_for_align),
            "anchorsUsed": m_anchors,
            "barEvents": aligned,
        }
        (CACHE_DIR / f"alignment{mvt}.json").write_text(json.dumps(out_align, ensure_ascii=False), encoding="utf-8")

        # Report summary + check key landmarks
        landmarks = {
            1: [(1, None), (17, None), (74, None), (138, None), (160, None), (218, None), (301, None), (427, None), (513, None), (547, None)],
            2: [(1, "p1"), (9, "p1r"), (151, "p1"), (159, "p1"), (400, "p1"), (412, "p1"), (428, "tr1"), (437, "tr2"), (507, "tr_out"), (1, "dc"), (159, "dc"), (547, "coda"), (575, "coda")],
            3: [(1, None), (3, None), (25, None), (43, None), (65, None), (83, None), (99, None), (121, None), (131, None), (157, None)],
            4: [(0, None), (1, None), (30, None), (48, None), (63, None), (92, None), (164, None), (208, None), (216, None), (241, None), (331, None), (431, None), (595, None), (655, None), (763, None), (851, None), (940, None)],
        }[mvt]
        print(f"=== M{mvt}: xml={parsed['xmlMeasureCount']} unrolled={len(bars_for_align)} music=[{s0_eff:.2f}..{audio['musicEndSec']:.2f}] dur={audio['duration']:.2f} ===")
        for bnum, occ in landmarks:
            match = next((x for x in aligned if x["bar"] == bnum and (occ is None or x["occ"] == occ)), None)
            if match:
                print(f"  m.{bnum:<3d} ({match['occ'] or '-':<6s}): {match['sec']:7.2f}s  db50={match['db50']:6.1f}dB  ts={match['timeSig']}")


if __name__ == "__main__":
    main()
