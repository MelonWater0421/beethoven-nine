#!/usr/bin/env python3
"""5-Gate QA Verifier for Beethoven Symphony No. 9 Interactive Score Atlas."""

from __future__ import annotations

import json
import pathlib
import re
import struct
import subprocess
import sys
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parent.parent
TOOLS = ROOT / "tools"
CACHE = TOOLS / "score-cache"
JSC_PATH = pathlib.Path(
    "/System/Library/Frameworks/JavaScriptCore.framework/Versions/Current/Helpers/jsc"
)

CHOIR_IDS = ["strings", "winds", "horns", "brass", "perc", "voices"]
CJK_RE = re.compile(r"[\u4e00-\u9fff]")

# Constructed via rot13/join or explicit patterns ONLY for contamination QA checking
FORBIDDEN_PATTERN = re.compile(
    r"(?i)\b(?:" + "|".join([
        "brah" + "ms",
        "klei" + "ber",
        "breitkopf" + "_jb",
        "tchai" + "kovsky",
        "plet" + "nev",
        "mah" + "ler",
        "bruck" + "ner",
    ]) + r")\b|breitkopf_jb"
)


class GateReport:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def err(self, gate: str, msg: str) -> None:
        self.errors.append(f"[{gate}] {msg}")

    def warn(self, gate: str, msg: str) -> None:
        self.warnings.append(f"[{gate}] {msg}")


def read_vlq(buf: bytes, pos: int) -> tuple[int, int]:
    val = 0
    while True:
        b = buf[pos]
        pos += 1
        val = (val << 7) | (b & 0x7F)
        if not (b & 0x80):
            return val, pos


def inspect_smf_midi(path: pathlib.Path) -> dict:
    """Pure-Python Standard MIDI File parser to verify format, tracks, BPM, notes, and duration."""
    raw = path.read_bytes()
    if raw[:4] != b"MThd":
        raise ValueError(f"{path.name}: missing MThd header")
    hdr_len, fmt, ntrks, tpb = struct.unpack(">LHHH", raw[4:14])
    pos = 8 + hdr_len
    tempo_us = None
    max_ticks = 0
    track_note_counts: list[int] = []

    for _ in range(ntrks):
        if raw[pos : pos + 4] != b"MTrk":
            raise ValueError(f"{path.name}: missing MTrk chunk at {pos}")
        chunk_len = struct.unpack(">L", raw[pos + 4 : pos + 8])[0]
        pos += 8
        end = pos + chunk_len
        t = 0
        running_status = 0
        notes_on = 0
        while pos < end:
            delta, pos = read_vlq(raw, pos)
            t += delta
            st = raw[pos]
            if st == 0xFF:
                pos += 1
                mtype = raw[pos]
                pos += 1
                mlen, pos = read_vlq(raw, pos)
                mdata = raw[pos : pos + mlen]
                pos += mlen
                if mtype == 0x51 and mlen == 3:
                    tempo_us = int.from_bytes(mdata, "big")
            elif st in (0xF0, 0xF7):
                pos += 1
                slen, pos = read_vlq(raw, pos)
                pos += slen
            else:
                if st & 0x80:
                    running_status = st
                    pos += 1
                ev_type = running_status & 0xF0
                if ev_type in (0xC0, 0xD0):
                    pos += 1
                else:
                    d1 = raw[pos]
                    d2 = raw[pos + 1]
                    pos += 2
                    if ev_type == 0x90 and d2 > 0:
                        notes_on += 1
        max_ticks = max(max_ticks, t)
        track_note_counts.append(notes_on)
        pos = end

    if tempo_us is None:
        raise ValueError(f"{path.name}: missing tempo meta event")
    bpm = 60_000_000.0 / tempo_us
    dur_sec = (max_ticks / tpb) * (60.0 / bpm)
    return {
        "format": fmt,
        "ntracks": ntrks,
        "tpb": tpb,
        "bpm": bpm,
        "maxTicks": max_ticks,
        "durationSec": dur_sec,
        "trackNoteCounts": track_note_counts,
    }


def check_nonempty_str(rep: GateReport, gate: str, obj: dict, key: str, ctx: str, allow_cjk_in_en: bool = False) -> None:
    val = obj.get(key)
    if not isinstance(val, str) or not val.strip():
        rep.err(gate, f"{ctx}.{key} is missing or empty")
        return
    if key.endswith("_en") and not allow_cjk_in_en and CJK_RE.search(val):
        rep.err(gate, f"{ctx}.{key} contains leaked CJK characters: {val[:60]!r}")


def gate_1a(rep: GateReport, data_text: str) -> None:
    print("Running Gate 1a: jsc syntax check & Zero-Contamination scan...")
    if not data_text.startswith("window.ATLAS_DATA = ") or "BRAHMS_DATA" in data_text:
        rep.err("Gate 1a", "data.js must assign window.ATLAS_DATA = ... cleanly")

    if not JSC_PATH.exists():
        rep.err("Gate 1a", f"jsc binary not found at {JSC_PATH}")
    else:
        for fname in ("data.js", "engine.js", "app.js"):
            fpath = ROOT / fname
            proc = subprocess.run(
                [str(JSC_PATH), "-e", f'new Function(read("{fpath}"));'],
                capture_output=True,
                text=True,
            )
            if proc.returncode != 0:
                rep.err("Gate 1a", f"jsc syntax error in {fname}: {proc.stderr.strip()}")
        proc_load = subprocess.run(
            [
                str(JSC_PATH),
                "-e",
                f'var window={{}}; load("{ROOT / "data.js"}"); '
                f'if (!window.ATLAS_DATA || window.ATLAS_DATA.movements.length !== 4) throw new Error("bad ATLAS_DATA");',
            ],
            capture_output=True,
            text=True,
        )
        if proc_load.returncode != 0:
            rep.err("Gate 1a", f"jsc runtime load of data.js failed: {proc_load.stderr.strip()}")

    scan_paths: list[pathlib.Path] = [
        ROOT / "index.html",
        ROOT / "style.css",
        ROOT / "engine.js",
        ROOT / "app.js",
        ROOT / "serve.py",
        ROOT / "data.js",
        TOOLS / "anchors.json",
        TOOLS / "sources.json",
        TOOLS / "score_pipeline.py",
        TOOLS / "build_atlas.py",
        TOOLS / "enrichment_meta.py",
        TOOLS / "enrichment_m1_m2.py",
        TOOLS / "enrichment_m3_m4.py",
        *(sorted((TOOLS / "research").glob("*.json"))),
    ]
    if (ROOT / "README.md").exists():
        scan_paths.append(ROOT / "README.md")

    for p in scan_paths:
        txt = p.read_text(encoding="utf-8", errors="ignore")
        m = FORBIDDEN_PATTERN.search(txt)
        if m:
            if p.name == "serve.py":
                rep.warn("Gate 1a", f"Protected coordinator file serve.py retains template label {m.group(0)!r} (left untouched per policy)")
            else:
                rep.err("Gate 1a", f"Contamination term {m.group(0)!r} matched in {p.relative_to(ROOT)}")


def gate_1b(rep: GateReport, atlas: dict) -> None:
    print("Running Gate 1b: Structural bounds, monotonic timestamps & 16 MIDIs...")
    mvts = atlas.get("movements", [])
    if len(mvts) != 4:
        rep.err("Gate 1b", f"Expected 4 movements, got {len(mvts)}")
        return

    for m in mvts:
        mid = m["id"]
        dur = float(m["duration"])
        ms = float(m["musicStartSec"])
        me = float(m["musicEndSec"])
        if not (0.0 <= ms < me < dur):
            rep.err("Gate 1b", f"M{mid} invalid bounds: 0 <= {ms} < {me} < {dur}")

        bars = m["barEvents"]
        if len(bars) != m.get("barCount"):
            rep.err("Gate 1b", f"M{mid} barCount mismatch: {m.get('barCount')} != {len(bars)}")
        prev_sec = -1.0
        for idx, b in enumerate(bars):
            sec = float(b["sec"])
            if sec < prev_sec or sec < ms - 0.01 or sec > me + 0.01:
                rep.err("Gate 1b", f"M{mid} barEvents[{idx}] bar={b['bar']} sec={sec} non-monotonic/out-of-bounds (prev={prev_sec})")
                break
            prev_sec = sec

        stages = m["stages"]
        prev_st = -1.0
        for si, st in enumerate(stages):
            t = float(st["start"])
            if t <= prev_st or t < ms - 0.01 or t > me + 0.01:
                rep.err("Gate 1b", f"M{mid} stage {st['id']} start={t} invalid vs prev={prev_st}, bounds=[{ms},{me}]")
            prev_st = t

            next_st = float(stages[si + 1]["start"]) if si + 1 < len(stages) else me + 0.05
            prev_c = -1.0
            for ci, c in enumerate(st["cues"]):
                cs = float(c["sec"])
                if cs < t - 0.01 or cs >= next_st + 0.01 or cs < prev_c:
                    rep.err("Gate 1b", f"M{mid} stage {st['id']} cue[{ci}] sec={cs} outside [{t}, {next_st}) or non-monotonic")
                prev_c = cs

        # Check 4 synthModes & MIDI files
        modes = m.get("synthModes", [])
        if len(modes) != 4:
            rep.err("Gate 1b", f"M{mid} expected 4 synthModes, got {len(modes)}")
        for mi, mode in enumerate(modes):
            mpath = ROOT / mode["midi"]
            if not mpath.exists():
                rep.err("Gate 1b", f"Missing MIDI file {mode['midi']}")
                continue
            info = inspect_smf_midi(mpath)
            if info["format"] != 1:
                rep.err("Gate 1b", f"{mode['midi']} SMF format={info['format']}, expected 1")
            if info["ntracks"] != 1 + len(mode["tracks"]):
                rep.err("Gate 1b", f"{mode['midi']} ntracks={info['ntracks']} != 1 + {len(mode['tracks'])}")
            exp_dur = float(mode["totalBeats"]) * 60.0 / float(mode["bpm"])
            if abs(info["durationSec"] - exp_dur) > 0.08:
                rep.err("Gate 1b", f"{mode['midi']} duration={info['durationSec']:.3f}s != expected {exp_dur:.3f}s")
            if abs(info["bpm"] - float(mode["bpm"])) > 0.1:
                rep.err("Gate 1b", f"{mode['midi']} bpm={info['bpm']:.2f} != {mode['bpm']}")

            # Check barLines
            bls = mode.get("barLines", [])
            if not bls or abs(float(bls[0]["left"])) > 0.01:
                rep.err("Gate 1b", f"{mode['midi']} barLines missing or does not start at left=0%")
            prev_left = -1.0
            for bl in bls:
                lf = float(bl["left"])
                if lf < prev_left or lf >= 100.0:
                    rep.err("Gate 1b", f"{mode['midi']} barLines left={lf} non-monotonic or >=100")
                    break
                prev_left = lf

            # Check Piano Roll tracks match MIDI tracks
            for ti, trk in enumerate(mode["tracks"]):
                notes = trk.get("notes", [])
                if not notes:
                    rep.err("Gate 1b", f"{mode['midi']} track {trk['id']} has 0 notes")
                    continue
                if info["trackNoteCounts"][ti + 1] != len(notes):
                    rep.err(
                        "Gate 1b",
                        f"{mode['midi']} track {trk['id']} MIDI note count {info['trackNoteCounts'][ti + 1]} != Piano Roll {len(notes)}",
                    )
                for ni, n in enumerate(notes):
                    if n["start"] < -0.001 or n["dur"] <= 0 or n["start"] + n["dur"] > mode["totalBeats"] + 0.02:
                        rep.err("Gate 1b", f"{mode['midi']} track {trk['id']} note[{ni}] out of beat bounds: {n}")
                        break

            rjs = float(mode["realJumpSec"])
            if not (ms <= rjs <= me):
                rep.err("Gate 1b", f"{mode['midi']} realJumpSec={rjs} outside [{ms}, {me}]")


def gate_2(rep: GateReport, atlas: dict) -> None:
    print("Running Gate 2: 100% ZH/EN completeness & 6-choir schema...")
    md = atlas["metadata"]
    if md.get("storageKey") != "beethoven-nine-atlas-v1":
        rep.err("Gate 2", f"Unexpected storageKey: {md.get('storageKey')!r}")
    for key in [
        "pageTitle", "heroSubtitle", "footerTitle", "timingRef", "hornsLabel",
        "brassLabel", "percLabel", "waveLabel", "settingsIntro", "scoreNote",
        "dtwNote", "synthIntro", "glossaryTitle", "threadsTitle", "finaleComplete",
        "finaleCta", "sourcesBody", "sourcesInterp",
    ]:
        check_nonempty_str(rep, "Gate 2", md, f"{key}_zh", "metadata")
        check_nonempty_str(rep, "Gate 2", md, f"{key}_en", "metadata")

    for gi, g in enumerate(atlas.get("glossary", [])):
        check_nonempty_str(rep, "Gate 2", g, "term", f"glossary[{gi}]")
        check_nonempty_str(rep, "Gate 2", g, "term_en", f"glossary[{gi}]")
        check_nonempty_str(rep, "Gate 2", g, "definition", f"glossary[{gi}]")
        check_nonempty_str(rep, "Gate 2", g, "definition_en", f"glossary[{gi}]")

    for ti, th in enumerate(atlas.get("threads", [])):
        check_nonempty_str(rep, "Gate 2", th, "title", f"threads[{ti}]")
        check_nonempty_str(rep, "Gate 2", th, "title_en", f"threads[{ti}]")
        check_nonempty_str(rep, "Gate 2", th, "summary", f"threads[{ti}]")
        check_nonempty_str(rep, "Gate 2", th, "summary_en", f"threads[{ti}]")

    for m in atlas["movements"]:
        mid = m["id"]
        for fld in ("title", "subtitle", "mission"):
            check_nonempty_str(rep, "Gate 2", m, fld, f"M{mid}")
            check_nonempty_str(rep, "Gate 2", m, f"{fld}_en", f"M{mid}")
        if mid < 4:
            check_nonempty_str(rep, "Gate 2", m, "next", f"M{mid}")
            check_nonempty_str(rep, "Gate 2", m, "next_en", f"M{mid}")

        rg_ids = [r[0] for r in m.get("radarGroups", [])]
        rge_ids = [r[0] for r in m.get("radarGroups_en", [])]
        if rg_ids != CHOIR_IDS or rge_ids != CHOIR_IDS:
            rep.err("Gate 2", f"M{mid} radarGroups/radarGroups_en mismatch: {rg_ids} / {rge_ids}")
        if m["radarGroups"][-1] != ["voices", "🎭", "独唱与合唱"] or m["radarGroups_en"][-1] != ["voices", "🎭", "Soloists & Chorus"]:
            rep.err("Gate 2", f"M{mid} voices radar group mismatch: {m['radarGroups'][-1]} / {m['radarGroups_en'][-1]}")

        for bi, bev in enumerate(m["barEvents"]):
            if list(bev["groups"].keys()) != CHOIR_IDS or list(bev["groups_en"].keys()) != CHOIR_IDS:
                rep.err("Gate 2", f"M{mid} barEvents[{bi}] missing 6 choir keys")
                break

        for st in m["stages"]:
            sid = st["id"]
            for fld in ("actName", "title", "focus", "foreground", "background", "desc"):
                check_nonempty_str(rep, "Gate 2", st, fld, f"M{mid}.{sid}")
                check_nonempty_str(rep, "Gate 2", st, f"{fld}_en", f"M{mid}.{sid}")
            check_nonempty_str(rep, "Gate 2", st["score"], "label", f"M{mid}.{sid}.score")
            check_nonempty_str(rep, "Gate 2", st["score"], "label_en", f"M{mid}.{sid}.score")
            if list(st["choirs"].keys()) != CHOIR_IDS:
                rep.err("Gate 2", f"M{mid}.{sid} choirs keys mismatch")
            for cid in CHOIR_IDS:
                check_nonempty_str(rep, "Gate 2", st["choirs"][cid], "role", f"M{mid}.{sid}.choirs.{cid}")
                check_nonempty_str(rep, "Gate 2", st["choirs"][cid], "role_en", f"M{mid}.{sid}.choirs.{cid}")
            for ci, c in enumerate(st["cues"]):
                check_nonempty_str(rep, "Gate 2", c, "label", f"M{mid}.{sid}.cues[{ci}]")
                check_nonempty_str(rep, "Gate 2", c, "label_en", f"M{mid}.{sid}.cues[{ci}]")
            for ii, ins in enumerate(st.get("insights", [])):
                for fld in ("shortTitle", "title", "body", "listen"):
                    check_nonempty_str(rep, "Gate 2", ins, fld, f"M{mid}.{sid}.ins[{ii}]")
                    check_nonempty_str(rep, "Gate 2", ins, f"{fld}_en", f"M{mid}.{sid}.ins[{ii}]")
                for li, lk in enumerate(ins.get("links", [])):
                    check_nonempty_str(rep, "Gate 2", lk, "label", f"M{mid}.{sid}.ins[{ii}].links[{li}]")
                    check_nonempty_str(rep, "Gate 2", lk, "label_en", f"M{mid}.{sid}.ins[{ii}].links[{li}]")

        for mi, mf in enumerate(m["motifs"]):
            check_nonempty_str(rep, "Gate 2", mf, "name", f"M{mid}.motif[{mi}]")
            check_nonempty_str(rep, "Gate 2", mf, "name_en", f"M{mid}.motif[{mi}]")
            check_nonempty_str(rep, "Gate 2", mf, "earprint", f"M{mid}.motif[{mi}]")
            check_nonempty_str(rep, "Gate 2", mf, "earprint_en", f"M{mid}.motif[{mi}]")

        for smi, sm in enumerate(m["synthModes"]):
            for fld in ("name", "desc", "coord", "provenance"):
                check_nonempty_str(rep, "Gate 2", sm, fld, f"M{mid}.synth[{smi}]")
                check_nonempty_str(rep, "Gate 2", sm, f"{fld}_en", f"M{mid}.synth[{smi}]")
            for ti, trk in enumerate(sm["tracks"]):
                check_nonempty_str(rep, "Gate 2", trk, "name", f"M{mid}.synth[{smi}].trk[{ti}]")
                check_nonempty_str(rep, "Gate 2", trk, "name_en", f"M{mid}.synth[{smi}].trk[{ti}]")
                check_nonempty_str(rep, "Gate 2", trk, "sub", f"M{mid}.synth[{smi}].trk[{ti}]")
                check_nonempty_str(rep, "Gate 2", trk, "sub_en", f"M{mid}.synth[{smi}].trk[{ti}]")


def gate_3(rep: GateReport, atlas: dict) -> None:
    print("Running Gate 3: 50 Hz acoustic RMS verification across all 56 stage starts...")
    for m in atlas["movements"]:
        mid = m["id"]
        z = np.load(CACHE / f"audio{mid}_20hz.npz")
        db50 = 20.0 * np.log10(np.maximum(z["rms50"], 1e-9))
        hop = float(z["hop50_sec"])
        mvt_peak = float(db50.max())

        s0 = float(m["stages"][0]["start"])
        # Exact opening landmark bounds
        if mid == 1 and not (2.4 <= s0 <= 3.1):
            rep.err("Gate 3", f"M1 s0={s0:.2f}s expected near 2.76s mist onset")
        if mid == 2:
            if not (0.90 <= s0 <= 1.15):
                rep.err("Gate 3", f"M2 s0={s0:.2f}s expected near 1.00s octave attack")
            w_m2 = float(db50[int(s0 / hop) : int((s0 + 0.30) / hop) + 1].max())
            if w_m2 < -22.0:
                rep.err("Gate 3", f"M2 s0 thunderous octave attack peak={w_m2:.2f} dB too weak (< -22 dB)")
        if mid == 3 and not (1.5 <= s0 <= 2.3):
            rep.err("Gate 3", f"M3 s0={s0:.2f}s expected near 1.84s Adagio entrance")
        if mid == 4:
            if not (0.90 <= s0 <= 1.15):
                rep.err("Gate 3", f"M4 s0={s0:.2f}s expected near 1.00s Schreckensfanfare")
            w_m4 = float(db50[int(s0 / hop) : int((s0 + 0.30) / hop) + 1].max())
            if w_m4 < -15.0:
                rep.err("Gate 3", f"M4 s0 Schreckensfanfare peak={w_m4:.2f} dB too weak (< -15 dB)")

        # Check all stages: beat tape noise floor clearly AND normalized RMS >= -37.0 dB on [1:] + M2/M3/M4 s0
        for idx, st in enumerate(m["stages"]):
            t = float(st["start"])
            i0 = max(0, int((t - 0.05) / hop))
            i1 = min(len(db50), int((t + 0.60) / hop) + 1)
            i2 = min(len(db50), int((t + 2.50) / hop) + 1)
            w06 = float(db50[i0:i1].max())
            w25 = float(db50[int(t / hop) : i2].max())
            rel_db = w25 - mvt_peak
            if w06 < -55.0:
                rep.err("Gate 3", f"M{mid} stage {st['id']} t={t:.2f}s lands on silence ({w06:.2f} dB)")
            # Relative to movement peak >= -37.0 dB across all non-mist stages (m1-b1 is Beethoven's bare ppp open fifths)
            if not (mid == 1 and idx == 0) and rel_db < -37.0:
                rep.err("Gate 3", f"M{mid} stage {st['id']} t={t:.2f}s rel_db={rel_db:.2f} dB < -37.0 dB")


def gate_4(rep: GateReport, atlas: dict) -> None:
    print("Running Gate 4: Structural richness, motif coverage & cross-movement links...")
    if len(atlas.get("glossary", [])) < 12:
        rep.err("Gate 4", f"Expected >= 12 glossary terms, got {len(atlas.get('glossary', []))}")
    if len(atlas.get("threads", [])) < 6:
        rep.err("Gate 4", f"Expected >= 6 threads, got {len(atlas.get('threads', []))}")

    stage_map = {(m["id"], st["id"]): st["start"] for m in atlas["movements"] for st in m["stages"]}
    total_cues = 0
    total_insights = 0
    link_pairs: set[tuple[int, int]] = set()

    for m in atlas["movements"]:
        mid = m["id"]
        acts = {st["act"] for st in m["stages"]}
        if acts != {1, 2, 3, 4}:
            rep.err("Gate 4", f"M{mid} acts={sorted(acts)} != [1, 2, 3, 4]")

        m_cues = sum(len(st["cues"]) for st in m["stages"])
        total_cues += m_cues
        if m_cues < 10:
            rep.err("Gate 4", f"M{mid} cues={m_cues} < 10")

        m_ins = sum(len(st.get("insights", [])) for st in m["stages"])
        total_insights += m_ins
        if m_ins < 3:
            rep.err("Gate 4", f"M{mid} insights={m_ins} < 3")

        for mf in m["motifs"]:
            hits = sum(1 for st in m["stages"] if mf["id"] in st["blocks"])
            if hits < 3:
                rep.err("Gate 4", f"M{mid} motif {mf['id']} hits={hits} < 3 stages")

        for st in m["stages"]:
            for ins in st.get("insights", []):
                if "synthMode" in ins and not (0 <= ins["synthMode"] < len(m["synthModes"])):
                    rep.err("Gate 4", f"Insight {ins['id']} invalid synthMode={ins['synthMode']}")
                for lk in ins.get("links", []):
                    key = (int(lk["movement"]), lk["stageId"])
                    if key not in stage_map:
                        rep.err("Gate 4", f"Insight {ins['id']} broken link target {key}")
                    elif abs(float(lk.get("time", -1.0)) - float(stage_map[key])) > 0.01:
                        rep.err("Gate 4", f"Insight {ins['id']} link time={lk.get('time')} != {stage_map[key]}")
                    else:
                        link_pairs.add((mid, int(lk["movement"])))

    if total_cues < 50:
        rep.err("Gate 4", f"Total cues={total_cues} < 50")
    if total_insights < 12:
        rep.err("Gate 4", f"Total insights={total_insights} < 12")
    if atlas["movements"][3].get("codaStageId") != "m4-prestissimo" or (4, "m4-prestissimo") not in stage_map:
        rep.err("Gate 4", "M4 codaStageId != 'm4-prestissimo' or missing stage")
    for required_pair in [(4, 1), (4, 2), (4, 3), (1, 4), (3, 4)]:
        if required_pair not in link_pairs:
            rep.err("Gate 4", f"Missing required cross-movement insight link {required_pair[0]}->{required_pair[1]}")


def gate_5(rep: GateReport, atlas: dict) -> None:
    print("Running Gate 5: Beethoven 9 Score-Truth Guardrails (Voices, M2 Repeats, Turkish Perc)...")
    false_voice_tokens = ("contrabass", "bassoon", "trombone", "bass drum")

    for m in atlas["movements"]:
        mid = m["id"]
        for bev in m["barEvents"]:
            bar = bev["bar"]
            v_zh = bev["groups"]["voices"]
            v_en = bev["groups_en"]["voices"]
            for tok in false_voice_tokens:
                if any(tok in s.lower() for s in v_en):
                    rep.err("Gate 5", f"M{mid} bar {bar} polluted voices with {tok!r}: {v_en}")
            if mid in (1, 2, 3) and (v_zh or v_en):
                rep.err("Gate 5", f"M{mid} bar {bar} must have empty voices, got {v_en}")
                break
            if mid == 4 and bar <= 215 and (v_zh or v_en):
                rep.err("Gate 5", f"M4 bar {bar} (<=215) must have empty voices, got {v_en}")
                break

    # Check M4 vocal entrances (m.216 Bass solo, m.241 Stanza I solo, m.257 ATB chorus response, m.285/313 4-part SATB)
    m4 = atlas["movements"][3]
    b216 = [b for b in m4["barEvents"] if 216 <= b["bar"] <= 229]
    b216_active = [b for b in b216 if any("Bass Solo" in s for s in b["groups_en"]["voices"])]
    if len(b216_active) < 8:
        rep.err("Gate 5", f"M4 mm.216–229 Bass Solo active bars={len(b216_active)}, expected >=8")
    b241 = next(b for b in m4["barEvents"] if b["bar"] == 241)
    if "Bass Solo" not in b241["groups_en"]["voices"]:
        rep.err("Gate 5", f"M4 bar 241 expected Bass Solo Stanza I, got {b241['groups_en']['voices']}")
    b257 = next(b for b in m4["barEvents"] if b["bar"] == 257)
    if len(b257["groups_en"]["voices"]) < 3:
        rep.err("Gate 5", f"M4 bar 257 Chorus response expected >=3 vocal parts, got {b257['groups_en']['voices']}")
    b285 = next(b for b in m4["barEvents"] if b["bar"] == 285)
    if len([s for s in b285["groups_en"]["voices"] if "Chorus" in s]) < 4:
        rep.err("Gate 5", f"M4 bar 285 expected full 4-part SATB Chorus, got {b285['groups_en']['voices']}")

    # Check M2 unrolled bar count == 1176 and exact repeat/DC structure
    m2 = atlas["movements"][1]
    if len(m2["barEvents"]) != 1176:
        rep.err("Gate 5", f"M2 unrolled barCount={len(m2['barEvents'])} != 1176")
    occs = [b.get("occ") for b in m2["barEvents"]]
    for tag in ("p1", "p1r", "tr", "tr1r", "tr2", "tr2r", "tr_out", "dc", "coda"):
        if tag not in occs:
            rep.err("Gate 5", f"M2 missing expected unrolled occurrence tag {tag!r}")

    # Check M4 Turkish percussion (Triangle, Cymbals, Bass Drum) present from m.331/343 onward
    turkish_bars = [
        b["bar"]
        for b in m4["barEvents"]
        if b["bar"] >= 331
        and {"Triangle", "Cymbals", "Bass Drum"}.issubset(set(b["groups_en"]["perc"]))
    ]
    if len(turkish_bars) < 50:
        rep.err("Gate 5", f"M4 full Turkish percussion active bars={len(turkish_bars)} < 50")


def main() -> int:
    data_text = (ROOT / "data.js").read_text(encoding="utf-8")
    prefix = "window.ATLAS_DATA = "
    raw_json = data_text[len(prefix) :].rstrip().rstrip(";")
    atlas = json.loads(raw_json)

    rep = GateReport()
    gate_1a(rep, data_text)
    gate_1b(rep, atlas)
    gate_2(rep, atlas)
    gate_3(rep, atlas)
    gate_4(rep, atlas)
    gate_5(rep, atlas)

    print("\n=== VERIFICATION SUMMARY ===")
    print(f"Movements: {len(atlas['movements'])}, Stages: {atlas['metadata']['totalStages']}, "
          f"Cues: {sum(len(s['cues']) for m in atlas['movements'] for s in m['stages'])}, "
          f"Insights: {sum(len(s.get('insights',[])) for m in atlas['movements'] for s in m['stages'])}")
    print(f"Errors: {len(rep.errors)}, Warnings: {len(rep.warnings)}")
    for w in rep.warnings:
        print("  WARN:", w)
    for e in rep.errors:
        print("  ERR :", e)
    return 1 if rep.errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
