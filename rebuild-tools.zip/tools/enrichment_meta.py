#!/usr/bin/env python3
"""Work metadata, edition sources, glossary, cross-movement threads, movement headers, and acts
for Beethoven's Symphony No. 9 in D minor, Op. 125 ("Choral") — Karajan / BPO (DG 1962/1963).
"""

PDF_BASE = (
    "https://s9.imslp.org/files/imglnks/usimg/1/11/"
    "IMSLP516486-PMLP1607-Beethoven_Breitkopf_Serie_1_Band_3_B_9_1_%28etc%29.pdf"
)


def pdf_url(page: int) -> str:
    return f"{PDF_BASE}#page={page}"


WORK_META = {
    "work": "Beethoven — Symphony No. 9 in D minor, Op. 125",
    "shortWork": "Beethoven · Symphony No. 9",
    "slug": "beethoven-9",
    "storageKey": "beethoven-nine-atlas-v1",
    "recordingLabel": "Karajan · BPO · Janowitz, Rössel-Majdan, Kmentt, Berry · Wiener Singverein (DG 1962)",
    "edition": "Breitkopf & Härtel, Serie 1 Nr. 9 (IMSLP516486)",
    "pageTitle_zh": "贝多芬第九交响曲《合唱》· 总谱全景导览",
    "pageTitle_en": "Beethoven Symphony No. 9 · Interactive Score Atlas",
    "heroSubtitle_zh": (
        "赫伯特·冯·卡拉扬指挥柏林爱乐乐团 · 雅诺维茨 / 勒塞尔-迈丹 / 克门特 / 贝里 · "
        "维也纳合唱协会（DG 1962 年 10 月录音 · 1963 年发行）"
    ),
    "heroSubtitle_en": (
        "Herbert von Karajan · Berliner Philharmoniker · Gundula Janowitz, Hilde Rössel-Majdan, "
        "Waldemar Kmentt, Walter Berry · Wiener Singverein (DG Oct 1962 / 1963)"
    ),
    "footerTitle_zh": "贝多芬 · d 小调第九交响曲，Op. 125《合唱》· 六声部交互总谱地图",
    "footerTitle_en": "Beethoven · Symphony No. 9 in D Minor, Op. 125 (\"Choral\") · Six-Choir Interactive Score Atlas",
    "timingRef_zh": "卡拉扬 / 柏林爱乐 1962 年 DG 版真实音轨对位",
    "timingRef_en": "Aligned to Karajan / BPO 1962 DG Recording",
    "hornsLabel_zh": "圆号 (4支)",
    "hornsLabel_en": "Horns (4)",
    "brassLabel_zh": "小号 / 长号",
    "brassLabel_en": "Trumpets / Trombones",
    "percLabel_zh": "定音鼓 / 弦外打击乐",
    "percLabel_en": "Timpani / Turkish Perc.",
    "waveLabel_zh": "1962 年 DG 录音实测声学波形（50 Hz 精度 · 点击跳转段落）",
    "waveLabel_en": "1962 DG Acoustic Envelope (50 Hz · Click anywhere to seek)",
    "settingsIntro_zh": (
        "本页已预加载卡拉扬 1962 年柏林爱乐版四乐章音频与逐小节总谱坐标（其中终曲整合了原专辑两轨为一整段）。"
        "你也可以加载自己的唱片音轨，利用每张卡片的「定位校准」建立私人版本映射。"
    ),
    "settingsIntro_en": (
        "Preloaded with Karajan's 1962 Berliner Philharmoniker recording (with Movement IV tracks 4a+4b merged "
        "seamlessly) and bar-by-bar OpenScore coordinates. You may also mount local recordings and recalibrate."
    ),
    "scoreNote_zh": (
        "总谱页码与小节号严格依据布赖特科普夫与黑特尔（Breitkopf & Härtel）全集第一辑第 9 号（共 276 页）；"
        "单簧管（Bb/C）、圆号（D/Bb/Eb）、小号（D/Bb）、短笛与低音大管/低音提琴均已还原为实音（Concert Pitch）。"
    ),
    "scoreNote_en": (
        "Measure numbers and PDF pages follow Breitkopf & Härtel Serie 1 Nr. 9 (276 pp.). Transposing winds, "
        "horns, trumpets, piccolo, contrabassoon, and contrabass are resolved to true sounding concert pitch."
    ),
    "dtwNote_zh": (
        "时间坐标通过 20 Hz 半音阶色度特征（CQT）与能量/起音包络动态时间规整（DTW）生成，"
        "并由关键结构入口的 50 Hz 声学瞬态锚点校准（含第二乐章 1,176 小节实际反复路径裁决）。"
    ),
    "dtwNote_en": (
        "Timestamps come from 20 Hz CQT chromagram + energy/onset DTW constrained by 50 Hz acoustic transient "
        "anchors across key structural landmarks, including empirical 1,176-bar repeat resolution for Movement II."
    ),
    "synthIntro_zh": (
        "下方钢琴卷帘直读总谱实音 MIDI（不含移调记谱误差），保留节拍与声部交织关系；"
        "可单独静音或独奏任一声部，听清复调如何叠加后再回到原声。"
    ),
    "synthIntro_en": (
        "Piano-roll excerpts preserve true concert-pitch score notation in steady study tempo so you can mute "
        "or solo individual choirs—strings, winds, horns, brass, percussion, and voices—before jumping to audio."
    ),
    "glossaryTitle_zh": "贝多芬第九交响曲 · 关键配器与结构术语手册",
    "glossaryTitle_en": "Beethoven Symphony No. 9 · Structural & Orchestration Glossary",
    "threadsTitle_zh": "贯穿全曲的六条戏剧主线",
    "threadsTitle_en": "Six Symphonic Threads Across the Ninth",
    "finaleComplete_zh": "全曲终了——从第一乐章荒原般的空五度雾气，到终曲急板齐颂的宇宙疆域，四大乐章已完成一次完整的声学巡礼。",
    "finaleComplete_en": "Cycle complete — from the primordial empty-fifth mist of Movement I to the Prestissimo apotheosis of Joy.",
    "finaleCta_zh": "重温终曲《急板》高潮",
    "finaleCta_en": "Revisit the Prestissimo Finale",
    "sourcesBody_zh": (
        "配器与小节体系以 Breitkopf & Härtel（Serie 1 Nr. 9，IMSLP516486）276 页德文标准总谱为准："
        "第一乐章 547 小节（PDF pp. 3–70）；第二乐章书面 575 小节、实奏 1,176 小节（pp. 71–143）；"
        "第三乐章 157 小节（pp. 144–172）；第四乐章含第 0 小节弱起至第 940 小节（pp. 174–276）。"
    ),
    "sourcesBody_en": (
        "Full-score references cite Breitkopf & Härtel Serie 1 Nr. 9 (IMSLP516486, 276 pp.): "
        "Mvt I (547 mm., pp. 3–70), Mvt II (575 written / 1,176 unrolled mm., pp. 71–143), "
        "Mvt III (157 mm., pp. 144–172), Mvt IV (upbeat bar 0 + 940 mm., pp. 174–276)."
    ),
    "sourcesInterp_zh": (
        "录音采用 1962 年 10 月卡拉扬 / 柏林爱乐 / 维也纳合唱协会 DG 历史名盘；"
        "第二乐章通过 9 组反复组合的 CQT+RMS 盲测比对，实证锁定仅反复谐谑曲呈示部（S1=T）、省略后半反复（S2=F）、"
        "并完整反复三声部两段（T1=T, T2=T）的 1,176 小节路径（DTW 最低代价 0.6735）。"
    ),
    "sourcesInterp_en": (
        "Aligned to Karajan's October 1962 Berlin studio recording for Deutsche Grammophon. "
        "Movement II repeat structure was verified across 9 CQT+RMS DTW candidates: Scherzo exposition repeat "
        "taken (S1=T), second half omitted (S2=F), both Trio repeats taken (T1=T, T2=T), da capo straight to Coda (1,176 bars)."
    ),
}

SOURCES = [
    {
        "title": "Breitkopf & Härtel Full Score (Serie 1 Nr. 9, IMSLP516486)",
        "url": PDF_BASE,
        "note": "Primary 276-page German engraved orchestral & choral score referenced for every stage page link and bar coordinate.",
    },
    {
        "title": "OpenScore Orchestra CC0 Digital Encoding (Op. 125)",
        "url": "https://musescore.com/openscore",
        "note": "Measure-accurate XML source across all four movements, transposed to sounding concert pitch for DTW and Piano Roll MIDI.",
    },
    {
        "title": "Karajan / Berliner Philharmoniker (DG 1962/1963 Studio Recording)",
        "url": "https://www.deutschegrammophon.com/",
        "note": "Jesus-Christus-Kirche, Berlin sessions (Oct–Nov 1962) with Janowitz, Rössel-Majdan, Kmentt, Berry, and Wiener Singverein.",
    },
    {
        "title": "Friedrich Schiller — An die Freude (1785 / 1803 Revision)",
        "url": "https://de.wikisource.org/wiki/An_die_Freude_(1808)",
        "note": "Poetic source selected and restructured by Beethoven across Movement IV mm. 216–940.",
    },
]

GLOSSARY = [
    {
        "term": "空五度创世雾气 (Empty-Fifth Mist)",
        "term_en": "Empty-Fifth Genesis Mist (Mvt I, mm. 1–16)",
        "definition": "圆号与低音弦乐持续 A–E 空五度，不含决定大/小调的三音 C# 或 C♮；第一、二小提琴如星尘般零星坠落五度音程，直到第 17 小节方才炸裂为 d 小调齐奏。",
        "definition_en": "Sustained horn and lower-string A–E fifths without a third (neither C# nor C♮), out of which upper-string fragments precipitate in accelerating fifths before collapsing into D minor at m. 17.",
    },
    {
        "term": "双主题变奏曲 (Dual-Theme Variations)",
        "term_en": "Alternating Dual-Theme Variations (Mvt III)",
        "definition": "第三乐章打破单一变奏惯例，交替呈示 Bb 大调 4/4《极富歌唱性的柔板》主题与 D 大调 / G 大调 3/4《中庸的行板》副歌，最终于 12/8 拍中融为一体。",
        "definition_en": "Rather than varying a single melody, Movement III alternates a 4/4 Bb Adagio hymn with a contrasting 3/4 Andante moderato refrain (in D and G major) before flowerings in 12/8 meter.",
    },
    {
        "term": "三小节/四小节拍组 (Ritmo di tre / quattro battute)",
        "term_en": "Ritmo di tre battute / di quattro battute",
        "definition": "贝多芬在第二乐章谐谑曲（3/4 拍）乐谱上亲笔标注的重音分组记号，令听觉不再每小节算一拍，而是将每 3 个（mm. 177–233）或每 4 个（mm. 234–247）小节捆绑成一个宏观大拍。",
        "definition_en": "Beethoven's explicit hypermetrical groupings in the 3/4 Scherzo: three-bar hypermeasures (mm. 177–233) shift suddenly to four-bar hypermeasures (mm. 234–247), warping perceived pulse.",
    },
    {
        "term": "第四圆号降E调独奏 (Fourth Horn Solo)",
        "term_en": "Fourth Horn Scale Solo in Cb / Bb (Mvt III, m. 83)",
        "definition": "贝多芬特意把第三乐章最险峻的高难度半音阶下潜乐段交予第 4 支降 E 调自然圆号（今常以带阀圆号吹奏），展现低音铜管少见的歌唱温暖与手塞音色彩。",
        "definition_en": "Assigned specifically to the 4th Horn in Eb to exploit the low hand-stopped register of the natural horn—famous for its lyrical Cb–Bb chromatic turn against pizzicato strings.",
    },
    {
        "term": "恐怖号角 / 不协和叠置 (Schreckensfanfare)",
        "term_en": "Fanfare of Terror (Mvt IV, mm. 0–7, 17–24)",
        "definition": "大提琴与低音提琴之前震撼全场的开篇喊杀：木管、铜管与定音鼓将降 B 大六和弦与 d 小调主和弦强行揉碎并置，形成令人窒息的七度与小二度摩擦。",
        "definition_en": "The brutal polytonal dissonant outcry opening the Finale, superimposing Bb major (VI) over the tonic D minor triad—referred to by Wagner as the 'Schreckensfanfare.'",
    },
    {
        "term": "器乐宣叙调与主题驳回 (Instrumental Recitative)",
        "term_en": "Instrumental Recitative & Quotation (Mvt IV, mm. 8–91)",
        "definition": "大提琴与低音提琴以无伴奏、类似歌剧男低音的吟诵语调（mm. 8–91），逐一引出前三个乐章的开头动机并断然摇头否定，直至木管吹出《欢乐颂》雏形方才欣然采纳。",
        "definition_en": "Cellos and contrabasses speak in wordless operatic recitative, calling up and dismissing the openings of Movements I, II, and III before embracing the nascent 'Freude' melody.",
    },
    {
        "term": "男低音领唱开场 (Baritone Appeal)",
        "term_en": "'O Freunde, nicht diese Töne!' (Mvt IV, m. 216)",
        "definition": "交响曲史上首次由人声打破纯器乐边界：在第二次《恐怖号角》爆发后，独唱男低音以近乎贝多芬亲撰的序言喊停喧嚣，号召众人转向《欢乐颂》。",
        "definition_en": "Beethoven's own prose preamble breaks the symphonic silence after the second horror fanfare, commanding the orchestra to abandon 'these tones' for songs of joy.",
    },
    {
        "term": "土耳其进行曲配器 (Janissary Band)",
        "term_en": "Alla Marcia / Turkish Band Scoring (Mvt IV, m. 331)",
        "definition": "第 331 小节转入 6/8 拍降 B 大调，低音大管与大鼓以远方行进的扑通脉冲开路，随后纳入短笛、三角铁与镲（所谓“土耳其禁卫军音乐”），与男高音领唱英勇对位。",
        "definition_en": "Swinging to Bb major in 6/8, Beethoven deploys contrabassoon and bass drum farts before piccolo, triangle, and cymbals evoke 18th-century 'Janissary' military music beneath the Tenor solo.",
    },
    {
        "term": "器乐双赋格间奏 (Alla Marcia Double Fugue)",
        "term_en": "Orchestral Battle Fugue (Mvt IV, mm. 431–542)",
        "definition": "继《土耳其进行曲》合唱高歌之后，全乐队以纯器乐展开 6/8 拍狂飙赋格，将欢乐动机变形为急切跳跃的英雄斗志，并突然调转回 D 大调齐唱。",
        "definition_en": "An athletic 6/8 orchestral fugue spun from the Alla Marcia variation of the Joy theme, driving through furious contrapuntal stretti back to a triumphant D major choral reprise.",
    },
    {
        "term": "全能兄弟大赞歌 (Seid umschlungen, Millionen)",
        "term_en": "Andante Maestoso Hymn in 3/2 (Mvt IV, m. 595)",
        "definition": "从 6/8 骤止切入庄严的 3/2 拍，三支长号与男声（次中音/男低音）如宗教赞美诗般同度宣唱；和声游走于 C 大调与神秘的弗里吉亚调式之间。",
        "definition_en": "Plunging from 6/8 frenzy into solemn 3/2 meter, three trombones and lower male chorus intone a liturgical unison invocation moving from G/C toward an awe-struck Phrygian/submediant abyss.",
    },
    {
        "term": "双主题双重赋格 (6/4 Double Fugue)",
        "term_en": "Choral Double Fugue (Mvt IV, mm. 655–762)",
        "definition": "贝多芬在终章中将两股人类精神合流为一：6/4 拍中女高音高唱跳跃的《欢乐颂》主旋律，女低音同步对位庄重长音符《亿万人民拥抱起来》，全篇精粹尽汇于此。",
        "definition_en": "The contrapuntal summit of the entire symphony: Sopranos sing the dactylic 'Freude' theme in 6/4 while Altos counter with the dotted-half-note 'Seid umschlungen' hymn simultaneously.",
    },
    {
        "term": "定音鼓八度顿击 (F-Octave Timpani)",
        "term_en": "Octave-Tuned Timpani in F (Mvt II)",
        "definition": "贝多芬首次在交响曲中将两面定音鼓调为相隔整八度的大调/同音（F3 与 F2），并在第二乐章第 1 小节及发展部三小节拍组中独挑主题核心重拍。",
        "definition_en": "Instead of tonic–dominant fourth/fifths, Movement II tunes the timpani to an F octave (F3–F2), turning percussion into a melodic/metric protagonist from the opening three-note attack.",
    },
]

THREADS = [
    {
        "title": "1. 从空五度混沌到 D 大调实体 (From Empty Fifth to Radiant D Major)",
        "title_en": "1. From Empty-Fifth Mist to D-Major Solidity",
        "summary": "第一乐章前 16 小节缺乏三音的 A–E 混沌，直到终曲第 241 小节《欢乐颂》清晰平稳的 D 大调级进音阶出现才得到彻底救赎——整部第九交响曲就是一场从“无调性核心的星云”凝结为“大地般确凿的旋律”的历程。",
        "summary_en": "The thirdless A–E void at the symphony's birth finds its ultimate answer in the stepwise, sunlit D major simplicity of the 'Freude' melody in the Finale.",
    },
    {
        "title": "2. 重锤般的降六级冲突：Bb 与 D 调的拉锯 (The Bb vs. D Axis)",
        "title_en": "2. The Bb / D Axis Across All Four Movements",
        "summary": "降 B（d 小调的降六级 bVI）如同命运的离心力：第一乐章副部落在降 B 大调、再现部前猛撞 d 小调主和弦；第三乐章整个安居于降 B 大调；第四乐章《恐怖号角》正是降 B 与 D 的尖锐对撞，最终由《土耳其进行曲》把降 B 接纳为欢乐的狂欢疆域。",
        "summary_en": "Bb (bVI of D minor) acts as the structural foil: second subject of Mvt I, home tonic of Mvt III, dissonant clash in Mvt IV's fanfare, and celebratory territory of the Alla Marcia.",
    },
    {
        "title": "3. 定音鼓与低音弦乐的双主角跃迁 (Timpani & Low Strings as Protagonists)",
        "title_en": "3. Low Strings and Timpani Take Center Stage",
        "summary": "从第一乐章再现部定音鼓长啸 37 小节的震天滚奏，到第二乐章 F 八度定音鼓独霸拍节、再至第四乐章大提琴与低音提琴开口“说话”与首次吟出《欢乐颂》，贝多芬颠覆了小提琴独占灵魂的传统交响层级。",
        "summary_en": "Reversing classical hierarchy, the timpani thunder across Mvt I's Recapitulation and drive Mvt II's Scherzo, while cellos and basses speak and birth the Joy theme in Mvt IV.",
    },
    {
        "title": "4. 终曲第 30–91 小节的记忆回溯 (The Finale's Memory Flashback)",
        "title_en": "4. Instrumental Recitative: Remembering & Rejecting Mvts I–III",
        "summary": "大提琴与低音提琴在终曲开场先后重温前三个乐章——暴风骤雨的空五度开篇、跳跃的八度谐谑曲、温柔叹息的柔板片段——并以一次次坚决的宣叙调将其礼貌却果断地请退历史舞台。",
        "summary_en": "At mm. 30, 48, and 63 of Movement IV, the orchestra flashes back directly to Movements I, II, and III, only for low strings to reject each past memory before embracing Joy.",
    },
    {
        "title": "5. 第六声部的降临：器乐向人声的拓扑突破 (Birth of the Choral Voice)",
        "title_en": "5. Breakthrough of the Sixth Choir: Soloists & Chorus",
        "summary": "前三乐章及第四乐章前 215 小节中，雷达图“独唱与合唱”声部始终处于沉寂休止；直至第 216 小节男低音猛然呼喊出人声的第一句叹息，交响曲才完成向宇宙庆典的最后维度跃升。",
        "summary_en": "Across Movements I–III and the first 215 bars of Movement IV, the Vocal choir sits silent—until Baritone 'O Freunde!' at m. 216 unlocks the full six-choir cosmos.",
    },
    {
        "title": "6. “人类之乐”与“神圣敬畏”的双赋格合一 (Two Ideas Becoming One)",
        "title_en": "6. Earthly Joy & Sacred Awe Fused in Double Fugue",
        "summary": "终曲并非单向喧闹，而是将平易近人的四拍子《欢乐颂》与带有文艺复兴复调神性的三拍子《亿万人民》合冶于第 655 小节 6/4 双赋格之中，达致世俗欢腾与形而上崇高的奇异共存。",
        "summary_en": "Beethoven pairs the folk-like 'Freude' theme with the liturgical 'Seid umschlungen' hymn inside the m. 655 6/4 Double Fugue—uniting human brotherhood with cosmic awe.",
    },
]

MOVEMENTS_META = {
    1: {
        "id": 1,
        "roman": "I",
        "shortEn": "Allegro ma non troppo, un poco maestoso",
        "title": "混沌初开与悲剧抗争 · 从微茫五度到再现雷霆",
        "title_en": "Allegro ma non troppo, un poco maestoso",
        "subtitle": "d 小调 2/4 拍 · 547 小节 · 奏鸣曲式悲剧弧线",
        "subtitle_en": "D minor · 2/4 · 547 mm. · Sonata Form",
        "mission": "听五度空响如何从近乎无声的弦乐碎屑中缓慢结晶，最终在第 301 小节再现为令人窒息的 D 大调雷暴，并在终曲葬礼进行曲式半音固定低音中沉沦。",
        "mission_en": "Follow empty-fifth mist as it condenses into tragic D-minor fury, erupts in the blazing D-major Recapitulation (m. 301), and sinks into the coda's chromatic abyss.",
        "next": "苦难并未停歇——第二乐章将立刻以 F 八度定音鼓与三小节超拍组撕裂沉郁，投入狂飙谐谑曲。",
        "next_en": "No rest follows: Movement II's octave-tuned timpani and fierce rhythmic drive shatter the tragic darkness.",
        "audio": "assets/movement-1.mp3",
        "rms": "assets/movement-1-rms.json",
        "palette": ["#64748b", "#d97706", "#ef4444", "#dc2626", "#f59e0b", "#b91c1c"],
    },
    2: {
        "id": 2,
        "roman": "II",
        "shortEn": "Molto vivace — Presto",
        "title": "星际跃动与田园急板 · 3/4 谐谑与 2/2 牧歌",
        "title_en": "Molto vivace — Presto",
        "subtitle": "d 小调 3/4 拍 & D 大调 2/2 拍 · 575 书面小节 / 实奏 1,176 小节",
        "subtitle_en": "D minor (3/4) & D major (2/2) · 575 written / 1,176 unrolled mm.",
        "mission": "锁定卡拉扬仅反复呈示部、双反复三声部的 1,176 小节实际路径；捕捉五声部赋格起兴、三小节/四小节节拍错位，与突然转入双簧管 D 大调牧歌时的时空静止。",
        "mission_en": "Track Karajan's verified 1,176-bar repeat map: five-voice fugato, 3-bar/4-bar hypermeter shifts, and the sudden radiant D-major Presto Trio.",
        "next": "谐谑曲狂澜褪去后，交响曲将在第三乐章陷入长达十六分钟、双主题交替流淌的无尽安魂冥想。",
        "next_en": "After the Scherzo coda flashes out, the orchestra opens an unhurried, two-theme Adagio meditation in Bb major.",
        "audio": "assets/movement-2.mp3",
        "rms": "assets/movement-2-rms.json",
        "palette": ["#dc2626", "#f59e0b", "#d97706", "#10b981", "#059669", "#eab308"],
    },
    3: {
        "id": 3,
        "roman": "III",
        "shortEn": "Adagio molto e cantabile — Andante moderato",
        "title": "双主题变奏的极境静观 · 第四圆号的温柔叹息",
        "title_en": "Adagio molto e cantabile — Andante moderato",
        "subtitle": "Bb 大调 4/4 / 3/4 / 12/8 拍 · 157 小节 · 双主题变奏曲",
        "subtitle_en": "Bb major · 4/4, 3/4 & 12/8 · 157 mm. · Dual-Theme Variations",
        "mission": "倾听第一主题《极其柔和歌唱的柔板》与第二主题《优雅的中庸行板》如何隔章对话；在第 83 小节守候第四圆号难忘的降 C 音深情独白，并警觉第 121、131 小节两次铜管天启号角的突然劈落。",
        "mission_en": "Trace the serene alternation of 4/4 Adagio and 3/4 Andante themes, wait for the 4th Horn solo at m. 83, and brace for the two startling Eb-major fanfares.",
        "next": "当降 B 大调最后的温柔余晖尚未消散，终曲的《恐怖号角》便以七度不协和撞击彻底碾碎了静谧……",
        "next_en": "Before the Adagio's final glow dissolves, Movement IV's brutal dissonant fanfare breaks every illusion of calm.",
        "audio": "assets/movement-3.mp3",
        "rms": "assets/movement-3-rms.json",
        "palette": ["#0ea5e9", "#0284c7", "#14b8a6", "#10b981", "#6366f1", "#f59e0b"],
    },
    4: {
        "id": 4,
        "roman": "IV",
        "shortEn": "Presto — Allegro assai (\"An die Freude\")",
        "title": "驳回过去与宇宙齐颂 · 六声部交响大终曲",
        "title_en": "Presto — Allegro assai (\"Ode to Joy\")",
        "subtitle": "d 小调 → D 大调 · 940 小节（含第 0 小节弱起）· 器乐宣叙与合唱变奏终曲",
        "subtitle_en": "D minor → D major · 940 mm. (+ Bar 0 upbeat) · Choral Variations & Double Fugue",
        "mission": "直击乐团如何回忆并逐一否定前三乐章，见证大提琴吐出《欢乐颂》、男低音第 216 小节唤醒第 6 声部（独唱与合唱），跨越土耳其进行曲、3/2 宏伟圣咏与 6/4 双赋格，冲向急板高潮。",
        "mission_en": "Witness the recitative rejections of Movements I–III, cellos voicing Joy, Baritone m. 216 awakening the 6th choir, the Turkish March, Double Fugue, and Prestissimo zenith.",
        "next": "",
        "next_en": "",
        "audio": "assets/movement-4.mp3",
        "rms": "assets/movement-4-rms.json",
        "codaStageId": "m4-prestissimo",
        "palette": ["#ef4444", "#dc2626", "#f59e0b", "#10b981", "#8b5cf6", "#eab308"],
    },
}

ACTS = {
    1: {
        1: ("第一幕 · 呈示部：空五度雾霭与降 B 调希望", "Act I · Exposition: Empty-Fifth Void & Bb Hope"),
        2: ("第二幕 · 发展部：动机拆解与五度风暴", "Act II · Development: Contrapuntal Storm"),
        3: ("第三幕 · 再现部：D 大调雷爆与命运逆转", "Act III · Recapitulation: D-Major Cataclysm"),
        4: ("第四幕 · 尾声：半音阶葬礼低音与沉沦", "Act IV · Coda: Chromatic Lament & Collapse"),
    },
    2: {
        1: ("第一幕 · 谐谑曲前半：五声赋格与重复呈示", "Act I · Scherzo Part I: Octave Attack & Repeated Exposition"),
        2: ("第二幕 · 发展与三/四小节超拍狂飙", "Act II · Scherzo Development: Three- & Four-Bar Hypermeter"),
        3: ("第三幕 · 三声部急板（Presto）：D 大调田园绿洲", "Act III · Presto Trio: D-Major Pastoral Oasis"),
        4: ("第四幕 · 从头反复（Da Capo）与急板尾声", "Act IV · Da Capo al Coda: Compressed Return & Flash Finale"),
    },
    3: {
        1: ("第一幕 · 柔板主题与行板副题初遇", "Act I · Adagio & Andante Themes Presented"),
        2: ("第二幕 · 第一变奏与 G 大调优雅回旋", "Act II · First Ornate Variation & G-Major Interlude"),
        3: ("第三幕 · 第 12/8 拍盛放与第四圆号独白", "Act III · 12/8 Flowering & Fourth Horn Solo"),
        4: ("第四幕 · 两次降 E 大调号角神启与温柔长眠", "Act IV · Twin Eb Fanfares & Plagal Dissolution"),
    },
    4: {
        1: ("第一幕 · 恐怖号角与前三乐章记忆驳回（mm. 0–91）", "Act I · Fanfare of Terror & Memory Flashbacks (mm. 0–91)"),
        2: ("第二幕 · 纯器乐的《欢乐颂》孕育与男低音召唤（mm. 92–330）", "Act II · Joy Unfolding in Strings & Baritone Appeal (mm. 92–330)"),
        3: ("第三幕 · 土耳其进行曲、器乐双赋格与兄弟圣咏（mm. 331–654）", "Act III · Turkish March, Battle Fugue & 'Seid umschlungen' (mm. 331–654)"),
        4: ("第四幕 · 6/4 双重赋格、柔板喘息与宇宙急板尾声（mm. 655–940）", "Act IV · 6/4 Double Fugue, Adagio Breath & Prestissimo (mm. 655–940)"),
    },
}
